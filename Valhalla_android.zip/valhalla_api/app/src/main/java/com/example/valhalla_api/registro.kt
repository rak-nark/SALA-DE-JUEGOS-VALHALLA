package com.example.valhalla_api

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class Registro : AppCompatActivity() {

    private lateinit var Nombre: EditText
    private lateinit var Apellido: EditText
    private lateinit var Correo: EditText
    private lateinit var Contrasena: EditText
    private lateinit var btnRegistrar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_registro)

        val textViewiniciarsesion: TextView = findViewById(R.id.iniciar_sesion)

        textViewiniciarsesion.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        Nombre = findViewById(R.id.Nombre)
        Apellido = findViewById(R.id.Apellido)
        Correo = findViewById(R.id.Correo)
        Contrasena = findViewById(R.id.Contrasena)
        btnRegistrar = findViewById(R.id.btnRegistrar)

        btnRegistrar.setOnClickListener { registrarCliente() }
    }


        private fun enviarDatosAlServidor (Nombre: String, Apellido: String, Correo: String, Contrasena: String) {
            val retrofit = Retrofit.Builder()
                .baseUrl("")
                .addConverterFactory(GsonConverterFactory.create())
                .build()

            val apiService = retrofit.create(Services::class.java)
            val call = apiService.registrarCliente(Nombre, Apellido, Correo, Contrasena)

            call.enqueue(object : Callback<ResponseBody>{
                override fun onResponse(cal: Call<ResponseBody>, response: Response<ResponseBody>) {
                    if (response.isSuccessful) {
                        Toast.makeText(this@Registro, "Registro Exitoso", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this@Registro, "Error en el Registro", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                    Toast.makeText(this@Registro, "Error de conexion", Toast.LENGTH_SHORT).show()
                }
            })
        }

        private fun registrarCliente() {

            val Nombre = Nombre.text.toString().trim()
            val Apellido = Apellido.text.toString().trim()
            val Correo = Correo.text.toString().trim()
            val Contrasena = Contrasena.text.toString().trim()

            if (Nombre.isEmpty() || Apellido.isEmpty() || Correo.isEmpty() || Contrasena.isEmpty()) {
                Toast.makeText(this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show()
                return
            }

            enviarDatosAlServidor (Nombre, Apellido, Correo, Contrasena)
        }

        /*
        fun limpiarCampos() {
            // Limpia los TextView y el EditText
            Nombre.text = "Nombre: "
            Apellido.text = "Apellido: "
            Correo.text = "Correo: "
            Contrasena.text = "Contrasena: "
            idCliente.text.clear()
        }

        btnLimpiar.setOnClickListener {
            limpiarCampos()
        }

        */

        /*

        btnRegistrar.setOnClickListener {
            val intent = Intent(this, AgregaPropietarioActivity::class.java)
            startActivity(intent)
        }

        btnEditar.setOnClickListener {
            val idCliente = idCliente.text.toString().toIntOrNull()
            if (idCliente != null && idCliente > 0) {
                val intent = Intent(this, EditarPropietarioActivity::class.java)
                intent.putExtra("CLIENTE_ID", idCliente)
                startActivity(intent)
            } else {
                Toast.makeText(this, "Ingrese un ID válido Mayor que Cero", Toast.LENGTH_SHORT).show()
            }
        }

        */

        /* fun clientesDatos(clienteId: Int) {
            // progressBar.visibility = View.VISIBLE
            RetrofitClient.instance.getClientes(clienteId).enqueue(object : Callback<ApiResponse> {
                override fun onResponse(call: Call<ApiResponse>, response: Response<ApiResponse>) {
                    // progressBar.visibility = View.GONE
                    if (response.isSuccessful) {
                        val apiResponse = response.body()
                        apiResponse?.let {
                            // Actualiza los TextView con los datos del propietario
                            Nombre.text = "Nombre: ${it.cliente.nombreCliente}"
                            Apellido.text = "Apellido: ${it.cliente.apellidoCliente}"
                            Correo.text = "Correo: ${it.cliente.correoCliente}"
                            Contrasena.text = "Contrasena: ${it.cliente.contrasenaCliente}"
                        }
                    } else {
                        Log.e("API", "Response error: ${response.errorBody()?.string()}")
                        Toast.makeText(this@Registro, "Error al obtener los datos", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onFailure(call: Call<ApiResponse>, t: Throwable) {
                    Log.e("API", "API Call Failed: ${t.message}")
                    Toast.makeText(this@Registro, "Error de conexión", Toast.LENGTH_SHORT).show()
                }
            })
        }

        btnConsultar.setOnClickListener {
            val idCliente1 = idCliente.text.toString().toIntOrNull()
            if (idCliente1 != null && idCliente1>0) {
                clientesDatos(idCliente1)
            } else {
                Toast.makeText(this, "Ingrese un ID válido Mayor que Cero", Toast.LENGTH_SHORT).show()
            }
        }
        */
}