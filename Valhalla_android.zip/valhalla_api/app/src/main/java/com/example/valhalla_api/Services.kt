package com.example.valhalla_api

import retrofit2.http.FormUrlEncoded
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.Field
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path

interface Services {

    @GET("cliente/{idCliente}")
    fun getCliente(@Path("idCliente") idCliente: Int): Call<cliente>

    @FormUrlEncoded
    @POST("cliente")
    fun registrarCliente(
        @Field("nombreCliente") nombre: String,
        @Field("apellidoCliente") apellido: String,
        @Field("correoCliente") correo: String,
        @Field("contrasenaCliente") contrasena: String
    ): Call<ResponseBody>

    @PUT("cliente/{idCliente}")
    fun actualizarCliente(
        @Path("idCliente") idCliente: Int,
        @Body cliente: cliente
    ): Call<ResponseBody>
}