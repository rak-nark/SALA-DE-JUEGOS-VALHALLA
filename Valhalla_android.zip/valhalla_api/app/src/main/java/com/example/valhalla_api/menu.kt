package com.example.valhalla_api

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class menu : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_menu)

        // Obtén la referencia del Spinner
        val combo = findViewById<Spinner>(R.id.spinnerOpciones)

        // Crea un ArrayAdapter usando el array de opciones definido en los recursos
        val adapter = ArrayAdapter.createFromResource(
            this,
            R.array.opciones,
            android.R.layout.simple_spinner_item
        )

        // Especifica el layout para el menú desplegable del Spinner
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        // Asigna el adapter al Spinner
        combo.adapter = adapter

        // Define un listener para manejar la selección de ítems en el Spinner
        combo.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                val selectedItem = parent.getItemAtPosition(position).toString()

                // Muestra un Toast con la opción seleccionada
                Toast.makeText(applicationContext, "Seleccionado: $selectedItem", Toast.LENGTH_SHORT).show()

                // Redirige a la actividad correspondiente según la opción seleccionada
                when (selectedItem) {
                    "Reservar Consolas" -> {
                        val intent = Intent(this@menu, reservar::class.java)
                        startActivity(intent)
                    }
                    // Aquí puedes agregar más casos para otras opciones si es necesario
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                // No se hace nada si no se selecciona nada
            }
        }
        val cerrarsesion: Button = findViewById(R.id.buttonCerrarSesion)


        cerrarsesion.setOnClickListener {

            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}