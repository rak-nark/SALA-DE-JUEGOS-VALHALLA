package com.example.valhalla_api

import com.google.gson.annotations.SerializedName

data class cliente(
    @SerializedName("idCliente") val idCliente: Int,
    @SerializedName("nombreCliente") val nombreCliente: String,
    @SerializedName("apellidoCliente") val apellidoCliente: String,
    @SerializedName("correoCliente") val correoCliente: String,
    @SerializedName("contrasenaCliente") val contrasenaCliente: String
)

data class ApiResponse(
    @SerializedName("cliente") val cliente: cliente,
    @SerializedName("status") val status: Int
)