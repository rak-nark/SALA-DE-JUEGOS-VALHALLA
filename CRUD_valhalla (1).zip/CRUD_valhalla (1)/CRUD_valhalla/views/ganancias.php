<?php 
include ("../connection/conexion.php");
include ("../controller/gananciasControlador.php");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Consulta de Ganancias</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../configs/css/consola.css">
</head>
<body>
<div class="wrapper">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
    <ul>
        <li><a href="home.php" title="Gestión usuarios"><i class="fa-solid fa-circle-user"></i><span
                    class="menu-text">Gestión Clientes</span></a></li>
        <li><a href="consola.php" title="Consolas"><i class="fa-solid fa-pager"></i><span
                    class="menu-text">Consolas</span></a></li>
        <li><a href="mantenimiento.php" title="Registrar Mantenimiento"><i class="fa-solid fa-book"></i><span
                    class="menu-text">Mantenimiento</span></a></li>
        <li><a href="prestamo.php" title="Prestamos"><i class="fa-solid fa-globe"></i><span
                    class="menu-text">Préstamos</span></a></li>
        <li><a href="venta.php" title="Consultar Ventas"><i class="fa-solid fa-money-bill-wave"></i><span
                    class="menu-text">Total Ventas</span></a></li>
       <li><a href="ganancias.php" title="Ganancias"><i class="fa-solid fa-chart-line"></i><span class="menu-text">Ganancias</span></a></li>
    </ul>
</div>

        <div class="main-content">
            <!-- Navbar superior -->
            <div class="navbar">
                <div class="navbar-left">
                    <button id="menuToggle"><i class="fas fa-bars"></i></button>
                    <span>Panel de Navegación</span>
                </div>
                <div class="navbar-right">
                    <div class="profile">Perfil <i class="fas fa-user"></i></div>
                    <div class="submenu">
                        <a href="#" class="submenu-toggle">Menú <i class="fas fa-bars"></i></a>
                        <div class="submenu-content">
                            <a href="login.php">Iniciar Sesión</a>
                            <a href="resgitro.php">Registrar</a>
                            <a href="logout.php">Cerrar Sesión</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Contenido -->
            <div class="content">
                <div class="container-md">
                    <nav class="navbar navbar-expand-lg navbar-light bg-light">
                        <div class="container-fluid">
                            <!-- Logo -->
                            <a class="navbar-brand" href="#">
                                <img src="../configs/image/Imagen2-removebg-preview (1).png" alt="Logo" width="150"
                                    height="100">
                            </a>
                            <!-- Botón para toggler en vista móvil -->
                            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                                aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>
                            <!-- Contenido del navbar -->
                            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                <!-- Menú de navegación -->
                                <form class="d-flex" method="post">
                                    <input class="form-control me-2" type="search" name="nombreCliente" id="idCliente"
                                        placeholder="Search" aria-label="Search">
                                    <button class="btn btn-outline-success" type="submit" name="buscar"
                                        id="buscar">Buscar</button>
                                </form>
                            </div>
                        </div>
                    </nav>
                    
    <div class="container mt-5">
        <h2 class="mb-4">Consulta de Ganancias </h2>
        
        <form method="POST" class="mb-4 d-flex gap-2">
            <label for="fecha_inicio">Fecha Inicio:</label>
            <input type="date" name="fecha_inicio" value="<?php echo $fecha_inicio; ?>" required>
            
            <label for="fecha_fin">Fecha Fin:</label>
            <input type="date" name="fecha_fin" value="<?php echo $fecha_fin; ?>" required>
            
            <button type="submit" class="btn btn-primary">Consultar</button>
        </form>

        <table class="table table-dark table-striped">
            <thead>
                <tr>
                    <th>Período</th>
                    <th>Ingresos estimados</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Desde <?php echo $fecha_inicio; ?> hasta <?php echo $fecha_fin; ?></td>
                    <td><?php echo number_format($ganancia_personalizada); ?></td>
                </tr>
            </tbody>
        </table>

        <a href="../views/home.php" class="btn btn-secondary">Volver</a>
    </div>

   
</div>

<!-- Scripts de Bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
