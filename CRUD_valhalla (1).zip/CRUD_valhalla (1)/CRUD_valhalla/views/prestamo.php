<?php 
include ("../connection/conexion.php");
include ("../controller/prestamoControlador.php"); 

$c = new conexion();
$cone = $c->conectando();

// Obtener el siguiente ID de préstamo
$sql = "SELECT MAX(idPrestamo) FROM prestamo";
$rs1 = mysqli_query($cone, $sql);
$arreglo = mysqli_fetch_row($rs1);
$suma = ($arreglo[0] > 0) ? $arreglo[0] + 1 : 1;
$obj->idPrestamo = $suma;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio de sesión</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../configs/css/prestamo.css">
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
    <ul>
        <li><a href="home.php" title="Gestión usuarios"><i class="fa-solid fa-circle-user"></i><span
                    class="menu-text">Gestión Clientes</span></a></li>
        <li><a href="consola.php" title="Consolas"><i class="fa-solid fa-pager"></i><span
                    class="menu-text">Consolas</span></a></li>
        <li><a href="mantenimiento.php" title="Registrar Mantenimiento"><i class="fa-solid fa-book"></i><span
                    class="menu-text">Mantenimiento</span></a></li>
        <li><a href="prestamo.php" title="Prestamos"><i class="fa-solid fa-globe"></i><span
                    class="menu-text">Préstamos</span></a></li>
        <li><a href="venta.php" title="Consultar Ventas"><i class="fa-solid fa-money-bill-wave"></i><span
                    class="menu-text">Total Ventas</span></a></li>
       <li><a href="ganancias.php" title="Ganancias"><i class="fa-solid fa-chart-line"></i><span class="menu-text">Ganancias</span></a></li>
    </ul>
</div>
        <div class="main-content">
            <!-- Navbar superior -->
            <div class="navbar">
                <div class="navbar-left">
                    <button id="menuToggle"><i class="fas fa-bars"></i></button>
                    <span>Panel de Navegación</span>
                </div>
                <div class="navbar-right">
                    <div class="profile">Perfil <i class="fas fa-user"></i></div>
                    <div class="submenu">
                        <a href="#" class="submenu-toggle">Menú <i class="fas fa-bars"></i></a>
                        <div class="submenu-content">
                            <a href="login.php">Iniciar Sesión</a>
                            <a href="resgitro.php">Registrar</a>
                            <a href="logout.php">Cerrar Sesión</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Contenido -->
            <div class="content">
                <div class="container-md">
                    <nav class="navbar navbar-expand-lg navbar-light bg-light">
                        <div class="container-fluid">
                            <!-- Logo -->
                            <a class="navbar-brand" href="#">
                                <img src="../configs/image/Imagen2-removebg-preview (1).png" alt="Logo" width="150"
                                    height="100">
                            </a>
                            <!-- Botón para toggler en vista móvil -->
                            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                                aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>
                            <!-- Contenido del navbar -->
                            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                <!-- Menú de navegación -->
                                <form class="d-flex" method="post">
                                    <input class="form-control me-2" type="search" name="nombreCliente" id="idCliente"
                                        placeholder="Search" aria-label="Search">
                                    <button class="btn btn-outline-success" type="submit" name="buscar"
                                        id="buscar">Buscar</button>
                                </form>
                            </div>
                        </div>
                    </nav>
                    <center>
    <nav>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
            Ingresar préstamo
        </button>
        <button type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#reservasModal">
            Ver reservas diarias
        </button>
    </nav>
</center>
<!-- Modal para mostrar reservas diarias -->
<div class="modal fade" id="reservasModal" tabindex="-1" aria-labelledby="reservasModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header bg-primary text-white">
                                <h5 class="modal-title" id="reservasModalLabel">Reservas del día</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                            </div>
                            <div class="modal-body">
                                <h4 class="text-center mb-3">Total de reservas hoy:</h4>
                                
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead class="table-dark">
                                            <tr>
                                                <th>Hora</th>
                                                <th>Tiempo de uso</th>
                                                <th>Consola</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $query = "SELECT p.hora, p.tiempodeuso, c.tipo 
                                                    FROM prestamo p
                                                    JOIN consola c ON p.id_consola = c.id
                                                    WHERE p.fecha = CURDATE()";
                                            $result = mysqli_query($cone, $query);

                                            if ($result && mysqli_num_rows($result) > 0) {
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                    echo "<tr>
                                                            <td>{$row['hora']}</td>
                                                            <td>{$row['tiempodeuso']} min</td>
                                                            <td>{$row['tipo']}</td>
                                                        </tr>";
                                                }
                                            } else {
                                                echo "<tr><td colspan='3' class='text-center'>No hay reservas para hoy.</td></tr>";
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                            </div>
                        </div>
                    </div>
                </div>


                <!-- Modal de Ingreso -->
                <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Ingrese los prestamos registrados</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form method="post">
                                    <div class="mb-3">
                                        <input type="hidden" name="idPrestamo" value="<?php echo $obj->idPrestamo ?>"
                                            class="form-control" id="exampleInputText1">
                                    </div>
                                    <div class="mb-3">
                                        <label for="fecha" class="form-label">Fecha</label>
                                        <input type="date" name="fecha" class="form-control" id="fecha" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="hora" class="form-label">Hora</label>
                                        <input type="time" name="hora" class="form-control" id="hora" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="tiempodeuso" class="form-label">Tiempo de uso</label>
                                        <select name="tiempodeuso" class="form-control" id="tiempodeuso" required>
                                            <option value="">Seleccione...</option>
                                            <option value="30">30 minutos</option>
                                            <option value="60">1 hora</option>
                                            <option value="90">1 hora y 30 minutos </option>
                                            <option value="120">2 horas</option>
                                            <option value="180">3 horas</option>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <!-- Campo oculto para reserva -->
                                        <input type="hidden" name="reserva" value="0">
                                    </div>
                                    <div class="mb-3">
                                        <!-- Campo oculto para id_cliente -->
                                        <input type="hidden" name="id_cliente" value="25">
                                    </div>
                                    <div class="mb-3">
                                            <label for="id_consola_<?php echo $res['idPrestamo']; ?>" class="form-label">ID Consola</label>
                                            <select name="id_consola" class="form-control" id="id_consola_<?php echo $res['idPrestamo']; ?>" required>
                                                <option value="">Seleccione una consola...</option>
                                                <?php
                                                // Array de consolas
                                                $consolas = [
                                                    ["id" => 1, "nombre" => "Xbox 360 1"],
                                                    ["id" => 2, "nombre" => "Xbox 360 2"],
                                                    ["id" => 3, "nombre" => "Xbox 360 3"],
                                                    ["id" => 4, "nombre" => "Xbox 360 4"],
                                                    ["id" => 5, "nombre" => "Xbox 360 5"],
                                                    ["id" => 6, "nombre" => "Xbox 360 6"],
                                                    ["id" => 7, "nombre" => "Xbox 360 7"],
                                                    ["id" => 8, "nombre" => "Xbox 360 8"],
                                                    ["id" => 9, "nombre" => "Xbox One 1"],
                                                    ["id" => 10, "nombre" => "Xbox One 2"],
                                                    ["id" => 11, "nombre" => "Xbox One 3"],
                                                    ["id" => 12, "nombre" => "Xbox One 4"],
                                                    ["id" => 13, "nombre" => "Xbox One 5"]
                                                ];

                                                // Generar las opciones del select
                                                foreach ($consolas as $consola) {
                                                    $selected = ($consola['id'] == $res['id_consola']) ? 'selected' : '';
                                                    echo "<option value='{$consola['id']}' $selected>{$consola['nombre']}</option>";
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    <button type="submit" class="btn btn-primary" name="guarda"
                                        value="guarda">Ingresar</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Tabla de prestamos -->
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th onclick="ordenarTabla(0)">Código</th>
                                <th onclick="ordenarTabla(1)">Fecha</th>
                                <th onclick="ordenarTabla(2)">Hora</th>
                                <th onclick="ordenarTabla(3)">Tiempo de uso</th>
                                <th onclick="ordenarTabla(4)">Reserva</th>
                                <th onclick="ordenarTabla(5)">ID_Cliente</th>
                                <th onclick="ordenarTabla(6)">ID_Consola</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
            if (!$res || mysqli_num_rows($ejecuta) == 0) {
                echo "<tr><td colspan='8' class='text-center'>No hay registros</td></tr>";
            } else {
                while ($res = mysqli_fetch_assoc($ejecuta)) {
            ?>
                            <tr>
                                <td>
                                    <?php echo $res['idPrestamo']; ?>
                                </td>
                                <td>
                                    <?php echo $res['fecha']; ?>
                                </td>
                                <td>
                                    <?php
                                    // Convertir la hora de formato 24 horas a 12 horas (AM/PM)
                                    echo date("h:i A", strtotime($res['hora']));
                                    ?>
                                </td>
                                <td>
                                    <?php echo $res['tiempodeuso']; ?> min
                                </td>
                                <td>
                                    <?php echo ($res['reserva'] == 1) ? "Sí" : "No"; ?>
                                </td>
                                <td>
                                    <?php echo $res['id_cliente']; ?>
                                </td>
                                <td>
                                    <?php
                                    // Array asociativo que mapea id_consola a nombre de consola
                                    $consolas = [
                                        1 => "Xbox 360 1",
                                        2 => "Xbox 360 2",
                                        3 => "Xbox 360 3",
                                        4 => "Xbox 360 4",
                                        5 => "Xbox 360 5",
                                        6 => "Xbox 360 6",
                                        7 => "Xbox 360 7",
                                        8 => "Xbox 360 8",
                                        9 => "Xbox One 1",
                                        10 => "Xbox One 2",
                                        11 => "Xbox One 3",
                                        12 => "Xbox One 4",
                                        13 => "Xbox One 5",
                                    ];

                                    // Mostrar el nombre de la consola usando el array
                                    echo $consolas[$res['id_consola']];
                                    ?>
                                </td>
                                <td>
                                    <form action="" method="post" style="display:inline;">
                                        <input type="hidden" name="idPrestamo"
                                            value="<?php echo $res['idPrestamo']; ?>">
                                        <button type="submit" name="elimina" class="btn btn-danger">Eliminar</button>
                                    </form>
                                    <!-- Botón para abrir el modal -->
                                    <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editModal_<?php echo $res['idPrestamo']; ?>">
                                        Editar
                                    </button>

                                    <!-- Modal de edición -->
                                    <div class="modal fade" id="editModal_<?php echo $res['idPrestamo']; ?>" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Editar Préstamo</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form method="post">
                                        <!-- Campo oculto para el ID del préstamo -->
                                        <input type="hidden" name="idPrestamo" value="<?php echo $res['idPrestamo']; ?>">

                                        <!-- Campo: Fecha -->
                                        <div class="mb-3">
                                            <label for="fecha_<?php echo $res['idPrestamo']; ?>" class="form-label">Fecha</label>
                                            <input type="date" name="fecha" class="form-control" id="fecha_<?php echo $res['idPrestamo']; ?>" value="<?php echo $res['fecha']; ?>" required>
                                        </div>

                                        <!-- Campo: Hora -->
                                        <div class="mb-3">
                                            <label for="hora_<?php echo $res['idPrestamo']; ?>" class="form-label">Hora</label>
                                            <input type="time" name="hora" class="form-control" id="hora_<?php echo $res['idPrestamo']; ?>" value="<?php echo $res['hora']; ?>" required>
                                        </div>

                                        <!-- Campo: Tiempo de uso -->
                                        <div class="mb-3">
                                            <label for="tiempo_<?php echo $res['idPrestamo']; ?>" class="form-label">Tiempo de uso</label>
                                            <select name="tiempodeuso" class="form-control" id="tiempo_<?php echo $res['idPrestamo']; ?>" required>
                                                <option value="30" <?php echo ($res['tiempodeuso'] == 30) ? 'selected' : ''; ?>>30 minutos</option>
                                                <option value="60" <?php echo ($res['tiempodeuso'] == 60) ? 'selected' : ''; ?>>1 hora</option>
                                                <option value="90" <?php echo ($res['tiempodeuso'] == 90) ? 'selected' : ''; ?>>1 hora 30 minutos</option>
                                                <option value="120" <?php echo ($res['tiempodeuso'] == 120) ? 'selected' : ''; ?>>2 horas</option>
                                                <option value="180" <?php echo ($res['tiempodeuso'] == 180) ? 'selected' : ''; ?>>3 horas</option>
                                            </select>
                                        </div>

                                        <!-- Campo: Reserva -->
                                        <div class="mb-3">
                                            <label for="reserva_<?php echo $res['idPrestamo']; ?>" class="form-label">Reserva</label>
                                            <select name="reserva" class="form-control" id="reserva_<?php echo $res['idPrestamo']; ?>" required>
                                                <option value="1" <?php echo ($res['reserva'] == 1) ? 'selected' : ''; ?>>Sí</option>
                                                <option value="0" <?php echo ($res['reserva'] == 0) ? 'selected' : ''; ?>>No</option>
                                            </select>
                                        </div>

                                        <!-- Campo: ID Cliente -->
                                        <div class="mb-3">
                                            <label for="id_cliente_<?php echo $res['idPrestamo']; ?>" class="form-label">ID Cliente</label>
                                            <input type="number" name="id_cliente" class="form-control" id="id_cliente_<?php echo $res['idPrestamo']; ?>" value="<?php echo $res['id_cliente']; ?>" required>
                                        </div>

                                        <!-- Campo: ID Consola -->
                                        <div class="mb-3">
                                            <label for="id_consola_<?php echo $res['idPrestamo']; ?>" class="form-label">ID Consola</label>
                                            <select name="id_consola" class="form-control" id="id_consola_<?php echo $res['idPrestamo']; ?>" required>
                                                <option value="">Seleccione una consola...</option>
                                                <?php
                                                // Array de consolas
                                                $consolas = [
                                                    ["id" => 1, "nombre" => "Xbox 360 1"],
                                                    ["id" => 2, "nombre" => "Xbox 360 2"],
                                                    ["id" => 3, "nombre" => "Xbox 360 3"],
                                                    ["id" => 4, "nombre" => "Xbox 360 4"],
                                                    ["id" => 5, "nombre" => "Xbox 360 5"],
                                                    ["id" => 6, "nombre" => "Xbox 360 6"],
                                                    ["id" => 7, "nombre" => "Xbox 360 7"],
                                                    ["id" => 8, "nombre" => "Xbox 360 8"],
                                                    ["id" => 9, "nombre" => "Xbox One 1"],
                                                    ["id" => 10, "nombre" => "Xbox One 2"],
                                                    ["id" => 11, "nombre" => "Xbox One 3"],
                                                    ["id" => 12, "nombre" => "Xbox One 4"],
                                                    ["id" => 13, "nombre" => "Xbox One 5"]
                                                ];

                                                // Generar las opciones del select
                                                foreach ($consolas as $consola) {
                                                    $selected = ($consola['id'] == $res['id_consola']) ? 'selected' : '';
                                                    echo "<option value='{$consola['id']}' $selected>{$consola['nombre']}</option>";
                                                }
                                                ?>
                                            </select>
                                        </div>

                                        <!-- Botón de enviar -->
                                        <button type="submit" name="modificar" class="btn btn-primary">Actualizar</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                            <?php
                }
            }
            ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <nav aria-label="Page navigation example">
                <ul class="pagination justify-content-end">
                    <?php 
            if ($pagina != 1) {
                ?>
                    <li class="page-item">
                        <a class="page-link" href="?pagina=<?php echo 1; ?>">Primera</a>
                    </li>
                    <li class="page-item">
                        <a class="page-link" href="?pagina=<?php echo $pagina - 1; ?>">Anterior</a>
                    </li>
                    <?php
            }
            for ($i = 1; $i <= $totalPaginas; $i++) {
                if ($i == $pagina) {
                    echo '<li class="page-item active" aria-current="page"><a class="page-link" href="?pagina='.$i.'">'.$i.'</a></li>';    
                } else {
                    echo '<li class="page-item"><a class="page-link" href="?pagina='.$i.'">'.$i.'</a></li>'; 
                }
            }
            if ($pagina != $totalPaginas) {
                ?>
                    <li class="page-item">
                        <a class="page-link" href="?pagina=<?php echo $pagina + 1; ?>">Siguiente</a>
                    </li>
                    <li class="page-item">
                        <a class="page-link" href="?pagina=<?php echo $totalPaginas; ?>">Ultima</a>
                    </li>
                    <?php
            }
            ?>
                </ul>
            </nav>
        </div>
    </div>
    </div>
    </div>
    <script>
    // Obtener la fecha y hora actual
    const fechaActual = new Date();

    // Formatear la fecha en el formato YYYY-MM-DD (requerido por input type="date")
    const año = fechaActual.getFullYear();
    const mes = String(fechaActual.getMonth() + 1).padStart(2, '0'); // Meses van de 0 a 11
    const dia = String(fechaActual.getDate()).padStart(2, '0');
    const fechaFormateada = `${año}-${mes}-${dia}`;

    // Formatear la hora en el formato HH:MM (requerido por input type="time")
    const horas = String(fechaActual.getHours()).padStart(2, '0');
    const minutos = String(fechaActual.getMinutes()).padStart(2, '0');
    const horaFormateada = `${horas}:${minutos}`;

    // Asignar la fecha y hora actual a los campos del formulario
    document.getElementById('fecha').value = fechaFormateada;
    document.getElementById('hora').value = horaFormateada;
    </script>
    <script src="../configs/js/prestamo.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>