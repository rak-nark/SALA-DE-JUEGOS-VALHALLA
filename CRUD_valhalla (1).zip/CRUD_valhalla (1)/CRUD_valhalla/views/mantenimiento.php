<?php 
include_once ("../connection/conexion.php");
include_once ("../controller/mantenimientoControlador.php");

// Funciones helper
if (!function_exists('getBadgeClass')) {
    function getBadgeClass($estado) {
        $classes = [
            'pendiente' => 'bg-secondary',
            'en_proceso' => 'bg-primary',
            'completado' => 'bg-success',
            'cancelado' => 'bg-danger',
            'vencido' => 'bg-warning text-dark'
        ];
        return $classes[$estado] ?? 'bg-secondary';
    }
}

if (!function_exists('getEstadoTexto')) {
    function getEstadoTexto($estado, $fechaProgramada = null) {
        $textos = [
            'pendiente' => 'Pendiente',
            'en_proceso' => 'En Proceso',
            'completado' => 'Completado',
            'cancelado' => 'Cancelado'
        ];
        
        if ($estado === 'pendiente' && $fechaProgramada) {
            $hoy = new DateTime();
            $fecha = new DateTime($fechaProgramada);
            
            if ($fecha < $hoy) {
                return 'Vencido';
            }
        }
        
        return $textos[$estado] ?? 'Desconocido';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Mantenimientos - Valhalla</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <link rel="stylesheet" href="../configs/css/mantenimiento.css">
    <style>
        .sidebar {
            min-height: 100vh;
            background: #343a40;
            color: white;
            transition: all 0.3s;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
        }
        .sidebar ul li a {
            color: white;
            padding: 10px 15px;
            display: block;
            text-decoration: none;
            transition: all 0.3s;
        }
        .sidebar ul li a:hover {
            background: #495057;
        }
        .sidebar .menu-text {
            margin-left: 10px;
        }
        .main-content {
            width: 100%;
        }
        .navbar {
            background: #f8f9fa;
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .content {
            padding: 20px;
        }
        .table-responsive {
            overflow-x: auto;
        }
        .completado {
            background-color: #e6ffec;
        }
        .en-proceso {
            background-color: #e6f2ff;
        }
        .vencido {
            background-color: #fff3e6;
        }
        .urgente {
            background-color: #ffebee;
            font-weight: bold;
        }
        .proximo {
            background-color: #fff8e1;
        }
        .cancelado {
            background-color: #f5f5f5;
            text-decoration: line-through;
            color: #999;
        }
        .search-form {
            max-width: 400px;
            margin-left: auto;
        }
        .pagination {
            justify-content: center;
            margin-top: 20px;
        }
        .badge {
            font-size: 0.9em;
            padding: 5px 10px;
        }
    </style>
</head>
<body>
    <div class="wrapper d-flex">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <ul>
                <li><a href="home.php" title="Gestión usuarios"><i class="fa-solid fa-circle-user"></i><span
                            class="menu-text">Gestión Clientes</span></a></li>
                <li><a href="consola.php" title="Consolas"><i class="fa-solid fa-pager"></i><span
                            class="menu-text">Consolas</span></a></li>
                <li><a href="mantenimiento.php" title="Registrar Mantenimiento"><i class="fa-solid fa-book"></i><span
                            class="menu-text">Mantenimiento</span></a></li>
                <li><a href="prestamo.php" title="Prestamos"><i class="fa-solid fa-globe"></i><span
                            class="menu-text">Préstamos</span></a></li>
                <li><a href="venta.php" title="Consultar Ventas"><i class="fa-solid fa-money-bill-wave"></i><span
                            class="menu-text">Total Ventas</span></a></li>
                <li><a href="ganancias.php" title="Ganancias"><i class="fa-solid fa-chart-line"></i><span class="menu-text">Ganancias</span></a></li>
            </ul>
        </div>

        <div class="main-content">
            <!-- Navbar -->
            <div class="navbar d-flex justify-content-between align-items-center">
                <div class="navbar-left d-flex align-items-center">
                    <button id="menuToggle" class="btn btn-outline-secondary me-3"><i class="fas fa-bars"></i></button>
                    <span class="h5 mb-0">Panel de Mantenimientos</span>
                </div>
                <div class="navbar-right">
                    <div class="profile d-flex align-items-center">
                        <span class="me-2">Administrador</span>
                        <i class="fas fa-user-circle fa-2x"></i>
                    </div>
                </div>
            </div>

            <!-- Contenido Principal -->
            <div class="content">
                <!-- Notificaciones -->
                <div id="notificaciones-mantenimiento" class="mb-4"></div>

                <!-- Barra de Herramientas -->
                <div class="toolbar mb-4">
                    <div class="row">
                        <div class="col-md-6">
                            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#nuevoMantenimientoModal">
                                <i class="fas fa-plus-circle"></i> Nuevo Mantenimiento
                            </button>
                        </div>
                        <div class="col-md-6">
                            <form class="d-flex search-form">
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Buscar mantenimientos..." id="buscador">
                                    <button class="btn btn-outline-secondary" type="button" id="btnBuscar">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Tabla de Mantenimientos -->
                <div class="card shadow-sm">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0"><i class="fas fa-list"></i> Listado de Mantenimientos</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <th>ID</th>
                                        <th>Tipo</th>
                                        <th>Consola</th>
                                        <th>Descripción</th>
                                        <th>Fecha Programada</th>
                                        <th>Estado</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody id="tabla-mantenimientos">
                                    <?php if (empty($mantenimientos)): ?>
                                        <tr>
                                            <td colspan="7" class="text-center">No hay mantenimientos registrados</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($mantenimientos as $m): ?>
                                        <tr class="<?= $m['clase_estado'] ?>">
                                            <td><?= htmlspecialchars($m['id']) ?></td>
                                            <td><?= ucfirst(htmlspecialchars($m['tipo'])) ?></td>
                                            <td><?= htmlspecialchars($m['tipo_consola']) ?> (ID: <?= $m['id_consola'] ?>)</td>
                                            <td><?= htmlspecialchars($m['descripcion']) ?></td>
                                            <td><?= date('d/m/Y', strtotime($m['fecha_programada'])) ?></td>
                                            <td>
                                                <span class="badge <?= getBadgeClass($m['estado']) ?>">
                                                    <?= getEstadoTexto($m['estado'], $m['fecha_programada']) ?>
                                                </span>
                                            </td>
                                            <td>
                                                <div class="btn-group">
                                                    <?php if ($m['estado'] === 'pendiente'): ?>
                                                        <button class="btn btn-sm btn-primary btn-iniciar" data-id="<?= $m['id'] ?>" title="Iniciar">
                                                            <i class="fas fa-play"></i>
                                                        </button>
                                                        <button class="btn btn-sm btn-danger btn-cancelar" data-id="<?= $m['id'] ?>" title="Cancelar">
                                                            <i class="fas fa-times"></i>
                                                        </button>
                                                    <?php elseif ($m['estado'] === 'en_proceso'): ?>
                                                        <button class="btn btn-sm btn-success btn-completar" data-id="<?= $m['id'] ?>" title="Completar">
                                                            <i class="fas fa-check"></i>
                                                        </button>
                                                    <?php endif; ?>
                                                    <button class="btn btn-sm btn-warning btn-editar" data-id="<?= $m['id'] ?>" title="Editar">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                    <button class="btn btn-sm btn-info btn-detalles" data-id="<?= $m['id'] ?>" title="Detalles">
                                                        <i class="fas fa-info-circle"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- Paginación -->
                        <?php if ($totalPaginas > 1): ?>
                        <nav aria-label="Page navigation">
                            <ul class="pagination">
                                <li class="page-item <?= $pagina <= 1 ? 'disabled' : '' ?>">
                                    <a class="page-link" href="?pagina=<?= $pagina - 1 ?>">Anterior</a>
                                </li>
                                <?php for ($i = 1; $i <= $totalPaginas; $i++): ?>
                                    <li class="page-item <?= $i == $pagina ? 'active' : '' ?>">
                                        <a class="page-link" href="?pagina=<?= $i ?>"><?= $i ?></a>
                                    </li>
                                <?php endfor; ?>
                                <li class="page-item <?= $pagina >= $totalPaginas ? 'disabled' : '' ?>">
                                    <a class="page-link" href="?pagina=<?= $pagina + 1 ?>">Siguiente</a>
                                </li>
                            </ul>
                        </nav>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Nuevo Mantenimiento -->
    <div class="modal fade" id="nuevoMantenimientoModal" tabindex="-1" aria-labelledby="nuevoMantenimientoModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="nuevoMantenimientoModalLabel"><i class="fas fa-plus-circle"></i> Nuevo Mantenimiento</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="formNuevoMantenimiento">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="agregar">
                        <div class="mb-3">
                            <label for="tipo" class="form-label">Tipo de Mantenimiento</label>
                            <select class="form-select" id="tipo" name="tipo" required>
                                <option value="">Seleccionar tipo...</option>
                                <option value="correctivo">Correctivo</option>
                                <option value="preventivo">Preventivo</option>
                                <option value="limpieza">Limpieza</option>
                                <option value="actualizacion">Actualización</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="id_consola" class="form-label">Consola</label>
                            <select class="form-select" id="id_consola" name="id_consola" required>
                                <option value="">Seleccionar consola...</option>
                                <?php foreach ($consolas as $consola): ?>
                                    <option value="<?= $consola['id'] ?>"><?= htmlspecialchars($consola['tipo']) ?> (ID: <?= $consola['id'] ?>)</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="descripcion" class="form-label">Descripción</label>
                            <textarea class="form-control" id="descripcion" name="descripcion" rows="3" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="fecha_programada" class="form-label">Fecha Programada</label>
                            <input type="date" class="form-control" id="fecha_programada" name="fecha_programada" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary">Guardar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Editar Mantenimiento -->
    <div class="modal fade" id="editarMantenimientoModal" tabindex="-1" aria-labelledby="editarMantenimientoModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-warning text-dark">
                    <h5 class="modal-title" id="editarMantenimientoModalLabel"><i class="fas fa-edit"></i> Editar Mantenimiento</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="formEditarMantenimiento">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="actualizar">
                        <input type="hidden" id="edit_id" name="id">
                        <div class="mb-3">
                            <label for="edit_tipo" class="form-label">Tipo de Mantenimiento</label>
                            <select class="form-select" id="edit_tipo" name="tipo" required>
                                <option value="correctivo">Correctivo</option>
                                <option value="preventivo">Preventivo</option>
                                <option value="limpieza">Limpieza</option>
                                <option value="actualizacion">Actualización</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="edit_id_consola" class="form-label">Consola</label>
                            <select class="form-select" id="edit_id_consola" name="id_consola" required>
                                <?php foreach ($consolas as $consola): ?>
                                    <option value="<?= $consola['id'] ?>"><?= htmlspecialchars($consola['tipo']) ?> (ID: <?= $consola['id'] ?>)</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="edit_descripcion" class="form-label">Descripción</label>
                            <textarea class="form-control" id="edit_descripcion" name="descripcion" rows="3" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="edit_fecha_programada" class="form-label">Fecha Programada</label>
                            <input type="date" class="form-control" id="edit_fecha_programada" name="fecha_programada" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-warning">Actualizar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Detalles Mantenimiento -->
    <div class="modal fade" id="detallesMantenimientoModal" tabindex="-1" aria-labelledby="detallesMantenimientoModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-info text-white">
                    <h5 class="modal-title" id="detallesMantenimientoModalLabel"><i class="fas fa-info-circle"></i> Detalles del Mantenimiento</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <strong>ID:</strong>
                            <p id="detalle_id"></p>
                        </div>
                        <div class="col-md-6">
                            <strong>Tipo:</strong>
                            <p id="detalle_tipo"></p>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <strong>Consola:</strong>
                            <p id="detalle_consola"></p>
                        </div>
                        <div class="col-md-6">
                            <strong>Estado:</strong>
                            <p id="detalle_estado"></p>
                        </div>
                    </div>
                    <div class="mb-3">
                        <strong>Descripción:</strong>
                        <p id="detalle_descripcion"></p>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <strong>Fecha Programada:</strong>
                            <p id="detalle_fecha_programada"></p>
                        </div>
                        <div class="col-md-6">
                            <strong>Fecha Creación:</strong>
                            <p id="detalle_created_at"></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <strong>Fecha Inicio:</strong>
                            <p id="detalle_fecha_inicio"></p>
                        </div>
                        <div class="col-md-6">
                            <strong>Fecha Fin:</strong>
                            <p id="detalle_fecha_fin"></p>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            // Toggle sidebar
            $('#menuToggle').click(function() {
                $('#sidebar').toggleClass('active');
            });

            // Iniciar mantenimiento
            $(document).on('click', '.btn-iniciar', function() {
                const id = $(this).data('id');
                Swal.fire({
                    title: '¿Iniciar este mantenimiento?',
                    text: "El estado cambiará a 'En Proceso'",
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Sí, iniciar',
                    cancelButtonText: 'Cancelar'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.post('', {action: 'iniciar', id: id}, function(response) {
                            if (response.success) {
                                Swal.fire('Éxito', response.message, 'success').then(() => location.reload());
                            } else {
                                Swal.fire('Error', response.message, 'error');
                            }
                        }, 'json');
                    }
                });
            });

            // Completar mantenimiento
            $(document).on('click', '.btn-completar', function() {
                const id = $(this).data('id');
                Swal.fire({
                    title: '¿Completar este mantenimiento?',
                    text: "El estado cambiará a 'Completado'",
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonColor: '#28a745',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Sí, completar',
                    cancelButtonText: 'Cancelar'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.post('', {action: 'completar', id: id}, function(response) {
                            if (response.success) {
                                Swal.fire('Éxito', response.message, 'success').then(() => location.reload());
                            } else {
                                Swal.fire('Error', response.message, 'error');
                            }
                        }, 'json');
                    }
                });
            });

            // Cancelar mantenimiento
            $(document).on('click', '.btn-cancelar', function() {
                const id = $(this).data('id');
                Swal.fire({
                    title: '¿Cancelar este mantenimiento?',
                    text: "El estado cambiará a 'Cancelado'",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#dc3545',
                    cancelButtonColor: '#6c757d',
                    confirmButtonText: 'Sí, cancelar',
                    cancelButtonText: 'No, mantener'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.post('', {action: 'cancelar', id: id}, function(response) {
                            if (response.success) {
                                Swal.fire('Éxito', response.message, 'success').then(() => location.reload());
                            } else {
                                Swal.fire('Error', response.message, 'error');
                            }
                        }, 'json');
                    }
                });
            });

            // Editar mantenimiento - Cargar datos en modal
            $(document).on('click', '.btn-editar', function() {
                const id = $(this).data('id');
                $.get('', {action: 'obtener', id: id}, function(data) {
                    if (data) {
                        $('#edit_id').val(data.id);
                        $('#edit_tipo').val(data.tipo);
                        $('#edit_id_consola').val(data.id_consola);
                        $('#edit_descripcion').val(data.descripcion);
                        $('#edit_fecha_programada').val(data.fecha_programada);
                        $('#editarMantenimientoModal').modal('show');
                    } else {
                        Swal.fire('Error', 'No se pudo cargar la información del mantenimiento', 'error');
                    }
                }, 'json');
            });

            // Enviar formulario de edición
            $('#formEditarMantenimiento').submit(function(e) {
                e.preventDefault();
                const formData = $(this).serialize();
                $.post('', formData, function(response) {
                    if (response.success) {
                        Swal.fire('Éxito', response.message, 'success').then(() => {
                            $('#editarMantenimientoModal').modal('hide');
                            location.reload();
                        });
                    } else {
                        Swal.fire('Error', response.message, 'error');
                    }
                }, 'json');
            });

            // Enviar formulario de nuevo mantenimiento
            $('#formNuevoMantenimiento').submit(function(e) {
    e.preventDefault();
    
    // Validación básica del cliente
    const fechaSeleccionada = new Date($('#fecha_programada').val());
    const hoy = new Date();
    hoy.setHours(0, 0, 0, 0);
    
    if (fechaSeleccionada < hoy) {
        Swal.fire('Error', 'No puedes programar un mantenimiento para una fecha pasada', 'error');
        return;
    }
    
    if ($('#descripcion').val().trim().length === 0) {
        Swal.fire('Error', 'La descripción no puede estar vacía', 'error');
        return;
    }
    
    // Mostrar loader
    const swalInstance = Swal.fire({
        title: 'Procesando',
        html: 'Por favor espere...',
        allowOutsideClick: false,
        didOpen: () => Swal.showLoading()
    });
    
    // Enviar la solicitud
    $.ajax({
        url: '../controller/mantenimientoControlador.php',
        type: 'POST',
        data: $(this).serialize(),
        dataType: 'json',
        success: function(response) {
            swalInstance.close();
            if (response && response.success) {
                Swal.fire({
                    title: 'Éxito',
                    text: response.message,
                    icon: 'success'
                }).then(() => {
                    $('#nuevoMantenimientoModal').modal('hide');
                    location.reload();
                });
            } else {
                Swal.fire('Error', response ? response.message : 'Respuesta inválida del servidor', 'error');
            }
        },
        error: function(xhr) {
            swalInstance.close();
            let errorMsg = 'Error en la comunicación con el servidor';
            try {
                const responseText = xhr.responseText;
                if (responseText.startsWith('{')) {
                    const response = JSON.parse(responseText);
                    errorMsg = response.message || errorMsg;
                } else {
                    console.error("Respuesta no JSON:", responseText);
                }
            } catch (e) {
                console.error("Error parseando respuesta:", e);
            }
            Swal.fire('Error', errorMsg, 'error');
        }
    });
});

            // Mostrar detalles
            $(document).on('click', '.btn-detalles', function() {
                const id = $(this).data('id');
                $.get('', {action: 'obtener', id: id}, function(data) {
                    if (data) {
                        $('#detalle_id').text(data.id);
                        $('#detalle_tipo').text(data.tipo.charAt(0).toUpperCase() + data.tipo.slice(1));
                        $('#detalle_consola').text(data.tipo_consola + ' (ID: ' + data.id_consola + ')');
                        $('#detalle_estado').html('<span class="badge ' + getBadgeClass(data.estado) + '">' + 
                            getEstadoTexto(data.estado, data.fecha_programada) + '</span>');
                        $('#detalle_descripcion').text(data.descripcion);
                        $('#detalle_fecha_programada').text(formatDate(data.fecha_programada));
                        $('#detalle_created_at').text(formatDateTime(data.created_at));
                        $('#detalle_fecha_inicio').text(data.fecha_inicio ? formatDateTime(data.fecha_inicio) : 'No iniciado');
                        $('#detalle_fecha_fin').text(data.fecha_fin ? formatDateTime(data.fecha_fin) : 'No completado');
                        $('#detallesMantenimientoModal').modal('show');
                    } else {
                        Swal.fire('Error', 'No se pudo cargar la información del mantenimiento', 'error');
                    }
                }, 'json');
            });

            // Funciones de ayuda
            function formatDate(dateString) {
                if (!dateString) return 'N/A';
                const date = new Date(dateString);
                return date.toLocaleDateString('es-ES');
            }

            function formatDateTime(dateTimeString) {
                if (!dateTimeString) return 'N/A';
                const date = new Date(dateTimeString);
                return date.toLocaleString('es-ES');
            }

            function getBadgeClass(estado) {
                const classes = {
                    'pendiente': 'bg-secondary',
                    'en_proceso': 'bg-primary',
                    'completado': 'bg-success',
                    'cancelado': 'bg-danger',
                    'vencido': 'bg-warning text-dark'
                };
                return classes[estado] || 'bg-secondary';
            }

            function getEstadoTexto(estado, fechaProgramada) {
                const textos = {
                    'pendiente': 'Pendiente',
                    'en_proceso': 'En Proceso',
                    'completado': 'Completado',
                    'cancelado': 'Cancelado'
                };
                
                if (estado === 'pendiente' && fechaProgramada) {
                    const hoy = new Date();
                    const fecha = new Date(fechaProgramada);
                    
                    if (fecha < hoy) {
                        return 'Vencido';
                    }
                }
                
                return textos[estado] || 'Desconocido';
            }

            // Buscador
            $('#btnBuscar').click(function() {
                const termino = $('#buscador').val().toLowerCase();
                if (termino) {
                    $('#tabla-mantenimientos tr').each(function() {
                        const textoFila = $(this).text().toLowerCase();
                        $(this).toggle(textoFila.includes(termino));
                    });
                } else {
                    $('#tabla-mantenimientos tr').show();
                }
            });

            // Validar fecha en el formulario
            $('#fecha_programada, #edit_fecha_programada').on('change', function() {
                const fechaSeleccionada = new Date($(this).val());
                const hoy = new Date();
                hoy.setHours(0, 0, 0, 0);
                
                if (fechaSeleccionada < hoy) {
                    Swal.fire('Advertencia', 'No puedes programar un mantenimiento para una fecha pasada', 'warning');
                    $(this).val('');
                }
            });
        });
    </script>
</body>
</html>