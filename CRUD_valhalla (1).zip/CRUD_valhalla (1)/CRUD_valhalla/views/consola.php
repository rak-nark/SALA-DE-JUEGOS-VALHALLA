<?php 
include ("../connection/conexion.php");
include ("../controller/consolaControlador.php");

// Crear instancia del controlador
$obj = new Consola();

// Obtener datos para mostrar
$resultados = $obj->listar();
$pagina = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consolas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../configs/css/consola.css">
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <ul>
                <li><a href="home.php" title="Gestión usuarios"><i class="fa-solid fa-circle-user"></i><span
                            class="menu-text">Gestión Clientes</span></a></li>
                <li><a href="consola.php" title="Consolas"><i class="fa-solid fa-pager"></i><span
                            class="menu-text">Consolas</span></a></li>
                <li><a href="mantenimiento.php" title="Registrar Mantenimiento"><i class="fa-solid fa-book"></i><span
                            class="menu-text">Mantenimiento</span></a></li>
                <li><a href="prestamo.php" title="Prestamos"><i class="fa-solid fa-globe"></i><span
                            class="menu-text">Préstamos</span></a></li>
                <li><a href="venta.php" title="Consultar Ventas"><i class="fa-solid fa-money-bill-wave"></i><span
                            class="menu-text">Total Ventas</span></a></li>
                <li><a href="ganancias.php" title="Ganancias"><i class="fa-solid fa-chart-line"></i><span class="menu-text">Ganancias</span></a></li>
            </ul>
        </div>
        <div class="main-content">
            <!-- Navbar superior -->
            <div class="navbar">
                <div class="navbar-left">
                    <button id="menuToggle"><i class="fas fa-bars"></i></button>
                    <span>Panel de Navegación</span>
                </div>
                <div class="navbar-right">
                    <div class="profile">Perfil <i class="fas fa-user"></i></div>
                    <div class="submenu">
                        <a href="#" class="submenu-toggle">Menú <i class="fas fa-bars"></i></a>
                        <div class="submenu-content">
                            <a href="login.php">Iniciar Sesión</a>
                            <a href="registro.php">Registrar</a>
                            <a href="logout.php">Cerrar Sesión</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Contenido -->
            <div class="content">
                <div class="container-md">
                    <nav class="navbar navbar-expand-lg navbar-light bg-light">
                        <div class="container-fluid">
                            <!-- Logo -->
                            <a class="navbar-brand" href="#">
                                <img src="../configs/image/Imagen2-removebg-preview (1).png" alt="Logo" width="150"
                                    height="100">
                            </a>
                            <!-- Botón para toggler en vista móvil -->
                            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                                aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>
                            <!-- Contenido del navbar -->
                            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                <!-- Menú de navegación -->
                                <form class="d-flex" method="post">
                                    <input class="form-control me-2" type="search" name="busqueda" 
                                        placeholder="Buscar por tipo" aria-label="Search">
                                    <button class="btn btn-outline-success" type="submit" name="buscar">Buscar</button>
                                </form>
                            </div>
                        </div>
                    </nav>
                    
                    <div class="table-responsive">
                        <!-- Tabla de consolas -->
                        <table class="table table-striped table-hover mt-3">
                            <thead>
                                <tr>
                                    <th>Código</th>
                                    <th>Tipo</th>
                                    <th>Estado</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($resultados && mysqli_num_rows($resultados) > 0): ?>
                                    <?php while($consola = mysqli_fetch_assoc($resultados)): ?>
                                    <tr>
                                        <td><?php echo $consola['id']; ?></td>
                                        <td><?php echo htmlspecialchars($consola['tipo']); ?></td>
                                        <td>
                                            <span class="badge 
                                                <?php echo $consola['estado'] == 'disponible' ? 'bg-success' : 
                                                      ($consola['estado'] == 'no_disponible' ? 'bg-danger' : 'bg-warning'); ?>">
                                                <?php echo ucfirst(str_replace('_', ' ', $consola['estado'])); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-warning btn-sm" data-bs-toggle="modal" 
                                                    data-bs-target="#editModal<?php echo $consola['id']; ?>">
                                                <i class="fas fa-edit"></i> Editar
                                            </button>
                                        </td>
                                    </tr>

                                    <!-- Modal de edición -->
                                    <div class="modal fade" id="editModal<?php echo $consola['id']; ?>" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Editar Estado</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <form method="post">
                                                    <div class="modal-body">
                                                        <input type="hidden" name="id" value="<?php echo $consola['id']; ?>">
                                                        
                                                        <div class="mb-3">
                                                            <label class="form-label">Tipo</label>
                                                            <input type="text" class="form-control" value="<?php echo htmlspecialchars($consola['tipo']); ?>" readonly>
                                                        </div>
                                                        
                                                        <div class="mb-3">
                                                            <label class="form-label">Estado</label>
                                                            <select name="estado" class="form-select" required>
                                                                <option value="disponible" <?= $consola['estado'] == 'disponible' ? 'selected' : '' ?>>Disponible</option>
                                                                <option value="no_disponible" <?= $consola['estado'] == 'no_disponible' ? 'selected' : '' ?>>No Disponible</option>
                                                                <option value="mantenimiento" <?= $consola['estado'] == 'mantenimiento' ? 'selected' : '' ?>>En Mantenimiento</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                                        <button type="submit" name="modificar" class="btn btn-primary">Guardar Cambios</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="4" class="text-center">No se encontraron consolas</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>

                        <!-- Paginación -->
                        <nav aria-label="Page navigation">
                            <ul class="pagination justify-content-center">
                                <?php if($pagina > 1): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?pagina=<?= $pagina-1 ?>" aria-label="Previous">
                                            <span aria-hidden="true">&laquo;</span>
                                        </a>
                                    </li>
                                <?php endif; ?>
                                
                                <?php for($i = 1; $i <= $totalPaginas; $i++): ?>
                                    <li class="page-item <?= $i == $pagina ? 'active' : '' ?>">
                                        <a class="page-link" href="?pagina=<?= $i ?>"><?= $i ?></a>
                                    </li>
                                <?php endfor; ?>
                                
                                <?php if($pagina < $totalPaginas): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?pagina=<?= $pagina+1 ?>" aria-label="Next">
                                            <span aria-hidden="true">&raquo;</span>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
            crossorigin="anonymous"></script>
        <script src="../configs/js/consola.js"></script>
</body>
</html>