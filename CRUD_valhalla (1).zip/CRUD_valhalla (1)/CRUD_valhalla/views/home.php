<?php 
include ("../connection/conexion.php");
include ("../controller/clienteControlador.php"); 
?>
<?php 
$c = new conexion();
$cone = $c->conectando();
$sql = "select max(idCliente) from cliente";
$rs1 = mysqli_query($cone, $sql);
$arreglo = mysqli_fetch_row($rs1);
$suma = ($arreglo[0] > 0) ? 1 + $arreglo[0] : 1;
$obj->idCliente = $suma;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio de sesión</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../configs/css/home.css">
    <!-- SweetAlert2 para mensajes más atractivos -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>  
    <div class="wrapper">
        <!-- Sidebar (sin cambios) -->
        <div class="sidebar" id="sidebar">
            <ul>
                <li><a href="home.php" title="Gestión usuarios"><i class="fa-solid fa-circle-user"></i><span
                            class="menu-text">Gestión Clientes</span></a></li>
                <li><a href="consola.php" title="Consolas"><i class="fa-solid fa-pager"></i><span
                            class="menu-text">Consolas</span></a></li>
                <li><a href="mantenimiento.php" title="Registrar Mantenimiento"><i class="fa-solid fa-book"></i><span
                            class="menu-text">Mantenimiento</span></a></li>
                <li><a href="prestamo.php" title="Prestamos"><i class="fa-solid fa-globe"></i><span
                            class="menu-text">Préstamos</span></a></li>
                <li><a href="venta.php" title="Consultar Ventas"><i class="fa-solid fa-money-bill-wave"></i><span
                            class="menu-text">Total Ventas</span></a></li>
            <li><a href= "ganancias.php" title="Ganancias"><i class="fa-solid fa-chart-line"></i><span class="menu-text">Ganancias</span></a></li>
            </ul>
        </div>
        <!-- ... (mantener el sidebar igual) ... -->

        <div class="main-content">
            <!-- Navbar (con pequeña mejora) -->
            <div class="navbar">
                <div class="navbar-left">
                    <button id="menuToggle"><i class="fas fa-bars"></i></button>
                    <span>Panel de Administración</span> <!-- Cambiado a "Administración" -->
                </div>
                <div class="navbar-right">
                    <div class="profile">Admin <i class="fas fa-user-shield"></i></div> <!-- Icono de admin -->
                </div>
            </div>

            <!-- Contenido principal con mejoras -->
            <div class="content">
                <div class="container-md">
                    <nav class="navbar navbar-expand-lg navbar-light bg-light mb-3">
                        <div class="container-fluid">
                            <a class="navbar-brand" href="#">
                                <img src="../configs/image/Imagen2-removebg-preview (1).png" alt="Logo" width="150" height="100">
                            </a>
                            <form class="d-flex ms-auto" method="post">
                                <input class="form-control me-2" type="search" name="nombreCliente" 
                                    placeholder="Buscar por nombre" aria-label="Search">
                                <button class="btn btn-outline-primary" type="submit" name="buscar">
                                    <i class="fas fa-search"></i>
                                </button>
                            </form>
                        </div>
                    </nav>

                    <div class="text-end mb-3">
                        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#nuevoClienteModal">
                            <i class="fas fa-plus-circle"></i> Nuevo Cliente
                        </button>
                    </div>

                    <!-- Modal para nuevo cliente (simplificado) -->
                    <div class="modal fade" id="nuevoClienteModal" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header bg-primary text-white">
                                    <h5 class="modal-title">Agregar Nuevo Cliente</h5>
                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form method="post">
                                        <div class="mb-3">
                                            <label class="form-label">Nombre</label>
                                            <input type="text" name="nombreCliente" class="form-control" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Apellido</label>
                                            <input type="text" name="apellidoCliente" class="form-control" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Correo</label>
                                            <input type="email" name="correoCliente" class="form-control" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Contraseña</label>
                                            <input type="password" name="contrasenaCliente" class="form-control" required>
                                        </div>
                                        <div class="text-end">
                                            <button type="submit" name="guarda" class="btn btn-primary">
                                                <i class="fas fa-save"></i> Guardar
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Tabla con mejoras visuales -->
                    <div class="table-responsive rounded-3 shadow-sm">
                        <table class="table table-striped table-hover">
                            <thead class="table-dark">
                                <tr>
                                    <th width="10%">ID</th>
                                    <th>Nombre</th>
                                    <th>Apellido</th>
                                    <th>Correo</th>
                                    <th width="15%">Rol</th>
                                    <th width="20%">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($res)): ?>
                                    <tr>
                                        <td colspan="6" class="text-center text-muted py-4">No hay registros de clientes</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($res as $fila): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($fila['idCliente']) ?></td>
                                        <td><?= htmlspecialchars($fila['nombreCliente']) ?></td>
                                        <td><?= htmlspecialchars($fila['apellidoCliente']) ?></td>
                                        <td><?= htmlspecialchars($fila['correoCliente']) ?></td>
                                        <td>
                                            <span class="badge bg-<?= $fila['rol'] === 'administrador' ? 'primary' : 'secondary' ?>">
                                                <?= ucfirst($fila['rol'] ?? 'usuario') ?>
                                            </span>
                                        </td>
                                        <td class="d-flex gap-2">
                                            <!-- Botón Editar con modal integrado -->
                                            <button type="button" class="btn btn-sm btn-warning" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#editModal<?= $fila['idCliente'] ?>">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            
                                        
                                            <!-- Formulario de eliminación (actualizado) -->
                                            
                                            <form method="post" class="d-inline">
                                                <input type="hidden" name="idCliente" value="<?= $fila['idCliente'] ?>">
                                                <button type="button" onclick="eliminarCliente(this)" class="btn btn-danger btn-sm">
                                                    <i class="fas fa-trash-alt"></i> Eliminar
                                                </button>
                                            </form>
                                        </td>
                                    </tr>

                                    <!-- Modal de Edición (para cada fila) -->
                                    <div class="modal fade" id="editModal<?= $fila['idCliente'] ?>" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header bg-warning text-dark">
                                                    <h5 class="modal-title">Editar Cliente #<?= $fila['idCliente'] ?></h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <form method="post">
                                                        <input type="hidden" name="idCliente" value="<?= $fila['idCliente'] ?>">
                                                        <div class="mb-3">
                                                            <label class="form-label">Nombre</label>
                                                            <input type="text" name="nombreCliente" class="form-control" 
                                                                value="<?= htmlspecialchars($fila['nombreCliente']) ?>" required>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label class="form-label">Apellido</label>
                                                            <input type="text" name="apellidoCliente" class="form-control" 
                                                                value="<?= htmlspecialchars($fila['apellidoCliente']) ?>" required>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label class="form-label">Correo</label>
                                                            <input type="email" name="correoCliente" class="form-control" 
                                                                value="<?= htmlspecialchars($fila['correoCliente']) ?>" required>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label class="form-label">Nueva Contraseña (dejar en blanco para no cambiar)</label>
                                                            <input type="password" name="contrasenaCliente" class="form-control">
                                                        </div>
                                                        <div class="mb-3">
                                                            <label class="form-label">Rol</label>
                                                            <select name="rol" class="form-select">
                                                                <option value="usuario" <?= ($fila['rol'] === 'usuario' || empty($fila['rol'])) ? 'selected' : '' ?>>Usuario</option>
                                                                <option value="administrador" <?= $fila['rol'] === 'administrador' ? 'selected' : '' ?>>Administrador</option>
                                                            </select>
                                                        </div>
                                                        <div class="text-end">
                                                            <button type="submit" name="modificar" class="btn btn-warning">
                                                                <i class="fas fa-sync-alt"></i> Actualizar
                                                            </button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Paginación mejorada -->
                    <nav aria-label="Page navigation">
                        <ul class="pagination justify-content-center mt-4">
                            <?php if($pagina > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?pagina=1" aria-label="First">
                                        <span aria-hidden="true">&laquo;&laquo;</span>
                                    </a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="?pagina=<?= $pagina - 1 ?>" aria-label="Previous">
                                        <span aria-hidden="true">&laquo;</span>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php 
                            // Mostrar solo 5 páginas alrededor de la actual
                            $inicio = max(1, $pagina - 2);
                            $fin = min($totalPaginas, $pagina + 2);
                            
                            for($i = $inicio; $i <= $fin; $i++): 
                            ?>
                                <li class="page-item <?= $i == $pagina ? 'active' : '' ?>">
                                    <a class="page-link" href="?pagina=<?= $i ?>"><?= $i ?></a>
                                </li>
                            <?php endfor; ?>

                            <?php if($pagina < $totalPaginas): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?pagina=<?= $pagina + 1 ?>" aria-label="Next">
                                        <span aria-hidden="true">&raquo;</span>
                                    </a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="?pagina=<?= $totalPaginas ?>" aria-label="Last">
                                        <span aria-hidden="true">&raquo;&raquo;</span>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

    <script src="../configs/js/home.js"></script>
    <script>
        // Función super simplificada
        async function eliminarCliente(btn) {
            const form = btn.closest('form');
            const confirmacion = await Swal.fire({
                title: '¿Eliminar?',
                text: "Los préstamos irán al usuario eliminado",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Sí, eliminar'
            });
            
            if (confirmacion.isConfirmed) {
                // Enviar formulario tradicional (sin AJAX)
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'elimina';
                input.value = '1';
                form.appendChild(input);
                form.submit();
            }
        }

        // Mensaje tras eliminar (si viene de redirección)
        <?php if(isset($_GET['eliminado'])): ?>
            Swal.fire('¡Eliminado!', 'Cliente eliminado correctamente', 'success');
        <?php endif; ?>
</script>
    
</body>
</html>