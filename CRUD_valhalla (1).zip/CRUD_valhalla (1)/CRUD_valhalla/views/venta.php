<?php 
include("../connection/conexion.php");
include("../controller/ventaControlador.php");
// Mensaje de bienvenida para administradores
// Conexión a la base de datos
$c = new conexion();
$cone = $c->conectando();
// Obtiene el último ID de la tabla 'venta'
$sql = "SELECT MAX(id) AS max_id FROM venta";
$rs1 = mysqli_query($cone, $sql);
// Inicializa las variables necesarias
$arreglo = mysqli_fetch_assoc($rs1);
if ($arreglo && $arreglo['max_id'] > 0) {
    $numero = $arreglo['max_id'];
    $suma = $numero + 1;
} else {
    $suma = 1; // Si no hay registros, inicia el ID en 1
}
// Asigna el nuevo ID al objeto
$obj->id = $suma;
// Continúa con la lógica de 'venta.php'...
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ventas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../configs/css/prestamo.css">
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
    <ul>
        <li><a href="home.php" title="Gestión usuarios"><i class="fa-solid fa-circle-user"></i><span
                    class="menu-text">Gestión Clientes</span></a></li>
        <li><a href="consola.php" title="Consolas"><i class="fa-solid fa-pager"></i><span
                    class="menu-text">Consolas</span></a></li>
        <li><a href="mantenimiento.php" title="Registrar Mantenimiento"><i class="fa-solid fa-book"></i><span
                    class="menu-text">Mantenimiento</span></a></li>
        <li><a href="prestamo.php" title="Prestamos"><i class="fa-solid fa-globe"></i><span
                    class="menu-text">Préstamos</span></a></li>
        <li><a href="venta.php" title="Consultar Ventas"><i class="fa-solid fa-money-bill-wave"></i><span
                    class="menu-text">Total Ventas</span></a></li>
       <li><a href="ganancias.php" title="Ganancias"><i class="fa-solid fa-chart-line"></i><span class="menu-text">Ganancias</span></a></li>
    </ul>
</div>
        <div class="main-content">
            <!-- Navbar superior -->
            <div class="navbar">
                <div class="navbar-left">
                    <button id="menuToggle"><i class="fas fa-bars"></i></button>
                    <span>Panel de Navegación</span>
                </div>
                <div class="navbar-right">
                    <div class="profile">Perfil <i class="fas fa-user"></i></div>
                    <div class="submenu">
                        <a href="#" class="submenu-toggle">Menú <i class="fas fa-bars"></i></a>
                        <div class="submenu-content">
                            <a href="login.php">Iniciar Sesión</a>
                            <a href="resgitro.php">Registrar</a>
                            <a href="logout.php">Cerrar Sesión</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Contenido -->
            <div class="content">
                <div class="container-md">
                    <nav class="navbar navbar-expand-lg navbar-light bg-light">
                        <div class="container-fluid">
                            <!-- Logo -->
                            <a class="navbar-brand" href="#">
                                <img src="../configs/image/Imagen2-removebg-preview (1).png" alt="Logo" width="150"
                                    height="100">
                            </a>
                            <!-- Botón para toggler en vista móvil -->
                            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                                aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>
                            <!-- Contenido del navbar -->
                            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                <!-- Menú de navegación -->
                                <form class="d-flex" method="post">
                                    <input class="form-control me-2" type="search" name="nombreCliente" id="idCliente"
                                        placeholder="Search" aria-label="Search">
                                    <button class="btn btn-outline-success" type="submit" name="buscar"
                                        id="buscar">Buscar</button>
                                </form>
                            </div>
                        </div>
                    </nav>
                    <center>
                        <nav>
                            <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                data-bs-target="#exampleModal">
                                Ingresar venta
                                <!-- Botón para abrir el modal -->
                             <button type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#modalGanancias">
                              Ganancias Diarias
                             </button>
                        </nav>
                        </nav>
                         <!-- Modal de Ganancias Diarias -->
    <div class="modal fade" id="modalGanancias" tabindex="-1" aria-labelledby="modalGananciasLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalGananciasLabel">Ganancias del Día</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <div class="modal-body">
                    <?php
                    $sql = "SELECT SUM(monto) AS total FROM venta WHERE fecha = CURDATE()";
                    $resultado = $conexion->query($sql);
                    $fila = $resultado->fetch_assoc();
                    $total_ganancias_hoy = $fila['total'] ?? 0;
                    ?>
                    <h4>Total de hoy: <strong><?php echo number_format($total_ganancias_hoy); ?></strong></h4>
                </div>
            </div>
        </div>
    </div>
                    </center>
                    <!-- Modal -->
                    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Ingrese los ventas registrados</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form method="post">
                                        <div class="mb-3">
                                            <input type="hidden" name="id" value="<?php echo $obj->id ?>"
                                                class="form-control" id="exampleInputText1">
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleInputText1" class="form-label">Fecha</label>
                                            <input type="date" name="fecha" class="form-control" id="exampleInputText1">
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleInputText1" class="form-label">Monto</label>
                                            <input type="number" name="monto" class="form-control"
                                                id="exampleInputText1">
                                        </div>
                                        <button type="submit" class="btn btn-primary" name="guarda"
                                            value="guarda">Ingresar</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover mt-3">
                            <thead>
                                <tr>
                                    <th scope="col">Código</th>
                                    <th scope="col">Fecha</th>
                                    <th scope="col">Monto</th>
                                    <th scope="col">Acciones</th>
                                    <th scope="col"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                    if ($res == 0) {
                        echo "<tr><td colspan='5' class='text-center'>No hay registros</td></tr>";
                    } else {
                        do {
                    ?>
                                <tr>
                                    <td>
                                        <?php echo $res[0] ?>
                                    </td>
                                    <td>
                                        <?php echo $res[1] ?>
                                    </td>
                                    <td>
                                        <?php echo $res[2] ?>
                                    </td>
                                    <td>
                                        <form action="" method="post">
                                            <input type="hidden" name="id" value="<?php echo $res[0]; ?>">
                                            <button type="submit" src="home.php" name="elimina" value="elimina"
                                                class="btn btn-danger">Eliminar</button>
                                        </form>
                                    </td>
                                    <td>
                                        <form action="" method="post">
                                            <input type="hidden" name="id" value="<?php echo $res[0]; ?>">
                                            <button type="button" class="btn btn-warning" data-bs-toggle="modal"
                                                data-bs-target="#editModal_<?php echo $res[0]; ?>">Editar</button>
                                            <div class="modal fade" id="editModal_<?php echo $res[0]; ?>" tabindex="-1"
                                                aria-labelledby="editModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="editModalLabel">Editar Venta
                                                            </h5>
                                                            <button type="button" class="btn-close"
                                                                data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <form method="post">
                                                                <input type="hidden" name="id"
                                                                    value="<?php echo $res[0]; ?>">
                                                                <div class="mb-3">
                                                                    <label for="fecha_<?php echo $res[0]; ?>"
                                                                        class="form-label">Fecha</label>
                                                                    <input type="date" name="fecha" class="form-control"
                                                                        id="fecha_<?php echo $res[0]; ?>"
                                                                        value="<?php echo $res[1]; ?>">
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label for="monto_<?php echo $res[0]; ?>"
                                                                        class="form-label">Monto</label>
                                                                    <input type="text" name="monto" class="form-control"
                                                                        id="monto_<?php echo $res[0]; ?>"
                                                                        value="<?php echo $res[2]; ?>">
                                                                </div>
                                                                <button type="submit" name="modificar" value="modificar"
                                                                    class="btn btn-primary">Actualizar</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </td>
                                </tr>
                                <?php
                        } while ($res = mysqli_fetch_array($ejecuta));
                    }
                    ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <nav aria-label="Page navigation example">
                        <ul class="pagination justify-content-end">
                            <?php 
                if ($pagina != 1) {
                ?>
                            <li class="page-item">
                                <a class="page-link" href="?pagina=<?php echo 1; ?>">&laquo;</a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="?pagina=<?php echo $pagina - 1; ?>">&lsaquo;</a>
                            </li>
                            <?php
                }
                for ($i = 1; $i <= $totalPaginas; $i++) {
                    if ($i == $pagina) {
                        echo '<li class="page-item active" aria-current="page"><a class="page-link" href="?pagina=' . $i . '">' . $i . '</a></li>';
                    } else {
                        echo '<li class="page-item"><a class="page-link" href="?pagina=' . $i . '">' . $i . '</a></li>';
                    }
                }
                if ($pagina != $totalPaginas) {
                ?>
                            <li class="page-item">
                                <a class="page-link" href="?pagina=<?php echo $pagina + 1; ?>">&rsaquo;</a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="?pagina=<?php echo $totalPaginas; ?>">&raquo;</a>
                            </li>
                            <?php
                }
                ?>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
            crossorigin="anonymous"></script>
            <script src="../configs/js/venta.js"></script>
</body>
</html>