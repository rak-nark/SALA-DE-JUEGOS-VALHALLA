<?php
include '../model/mantenimientoModelo.php';
include '../model/consolaModelo.php';

class MantenimientoController {
    private $mantenimientoModel;
    private $consolaModel;

    public function __construct() {
        $this->mantenimientoModel = new MantenimientoModelo();
        $this->consolaModel = new Consola();
    }

    public function handleRequest() {
        try {
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $this->handlePost();
            } else {
                $this->displayMantenimientos();
            }
        } catch (Exception $e) {
            $this->handleError($e->getMessage());
        }
    }

    private function handlePost() {
        if (!isset($_POST['action'])) {
            $this->jsonResponse(false, 'Acción no especificada');
        }

        // Verificar token CSRF aquí en una implementación real
        // $this->verifyCsrfToken();

        switch ($_POST['action']) {
            case 'agregar':
                $this->agregarMantenimiento();
                break;
            case 'actualizar':
                $this->actualizarMantenimiento();
                break;
            case 'iniciar':
                $this->iniciarMantenimiento();
                break;
            case 'completar':
                $this->completarMantenimiento();
                break;
            case 'cancelar':
                $this->cancelarMantenimiento();
                break;
            default:
                $this->jsonResponse(false, 'Acción no válida');
        }
    }

    private function agregarMantenimiento() {
        $requiredFields = ['tipo', 'descripcion', 'id_consola', 'fecha_programada'];
        $this->validatePostData($requiredFields);

        $data = [
            'tipo' => $_POST['tipo'],
            'descripcion' => $_POST['descripcion'],
            'id_consola' => (int)$_POST['id_consola'],
            'fecha_programada' => $_POST['fecha_programada']
        ];

        try {
            $success = $this->mantenimientoModel->agregar($data);
            if ($success) {
                $this->consolaModel->actualizarEstado($data['id_consola'], 'mantenimiento');
                $this->jsonResponse(true, 'Mantenimiento programado');
            }
            $this->jsonResponse(false, 'Error al programar el mantenimiento');
        } catch (Exception $e) {
            $this->jsonResponse(false, $e->getMessage());
        }
    }

    private function actualizarMantenimiento() {
        $requiredFields = ['id', 'tipo', 'descripcion', 'id_consola', 'fecha_programada'];
        $this->validatePostData($requiredFields);

        $data = [
            'id' => (int)$_POST['id'],
            'tipo' => $_POST['tipo'],
            'descripcion' => $_POST['descripcion'],
            'id_consola' => (int)$_POST['id_consola'],
            'fecha_programada' => $_POST['fecha_programada']
        ];

        try {
            $success = $this->mantenimientoModel->actualizar($data);
            $this->jsonResponse($success, $success ? 'Mantenimiento actualizado' : 'Error al actualizar');
        } catch (Exception $e) {
            $this->jsonResponse(false, $e->getMessage());
        }
    }

    private function iniciarMantenimiento() {
        $this->validatePostData(['id']);
        $id = (int)$_POST['id'];

        try {
            $success = $this->mantenimientoModel->iniciar($id);
            if ($success) {
                $mantenimiento = $this->mantenimientoModel->obtenerPorId($id);
                $this->consolaModel->actualizarEstado($mantenimiento['id_consola'], 'mantenimiento');
                $this->jsonResponse(true, 'Mantenimiento iniciado');
            }
            $this->jsonResponse(false, 'Error al iniciar el mantenimiento');
        } catch (Exception $e) {
            $this->jsonResponse(false, $e->getMessage());
        }
    }

    private function completarMantenimiento() {
        $this->validatePostData(['id']);
        $id = (int)$_POST['id'];

        try {
            $success = $this->mantenimientoModel->completar($id);
            if ($success) {
                $mantenimiento = $this->mantenimientoModel->obtenerPorId($id);
                $this->consolaModel->actualizarEstado($mantenimiento['id_consola'], 'disponible');
                $this->jsonResponse(true, 'Mantenimiento completado');
            }
            $this->jsonResponse(false, 'Error al completar el mantenimiento');
        } catch (Exception $e) {
            $this->jsonResponse(false, $e->getMessage());
        }
    }

    private function cancelarMantenimiento() {
        $this->validatePostData(['id']);
        $id = (int)$_POST['id'];

        try {
            $mantenimiento = $this->mantenimientoModel->obtenerPorId($id);
            $success = $this->mantenimientoModel->cancelar($id);
            
            if ($success) {
                if ($mantenimiento['estado'] === 'en_proceso') {
                    $this->consolaModel->actualizarEstado($mantenimiento['id_consola'], 'disponible');
                }
                $this->jsonResponse(true, 'Mantenimiento cancelado');
            }
            $this->jsonResponse(false, 'Error al cancelar el mantenimiento');
        } catch (Exception $e) {
            $this->jsonResponse(false, $e->getMessage());
        }
    }

    private function displayMantenimientos() {
        $pagina = isset($_GET['pagina']) ? max(1, (int)$_GET['pagina']) : 1;
        $porPagina = 10;
        
        try {
            $data = [
                'mantenimientos' => $this->mantenimientoModel->listar($pagina, $porPagina),
                'total' => $this->mantenimientoModel->contar(),
                'totalPaginas' => ceil($this->mantenimientoModel->contar() / $porPagina),
                'consolas' => $this->consolaModel->listar(),
                'pagina' => $pagina,
                'porPagina' => $porPagina
            ];
        
            extract($data);
            include '../views/mantenimiento.php';
        } catch (Exception $e) {
            $this->handleError($e->getMessage());
        }
    }

    private function validatePostData($requiredFields) {
        foreach ($requiredFields as $field) {
            if (!isset($_POST[$field]) || empty($_POST[$field])) {
                $this->jsonResponse(false, "El campo $field es requerido");
            }
        }
    }

    private function jsonResponse($success, $message, $data = []) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => $success,
            'message' => $message,
            'data' => $data
        ]);
        exit;
    }

    private function handleError($message) {
        // Loggear el error
        error_log("Error en MantenimientoController: " . $message);
        
        // Mostrar error al usuario
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->jsonResponse(false, "Ocurrió un error: " . $message);
        } else {
            // Mostrar página de error
            include '../views/error.php';
            exit;
        }
    }
}

// Ejecutar el controlador
$controller = new MantenimientoController();
$controller->handleRequest();
?>