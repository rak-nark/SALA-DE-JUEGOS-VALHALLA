<?php
class MantenimientoModelo {
    private $conexion;

    public function __construct() {
        $this->conexion = new Conexion();
    }

    /**
     * Lista los mantenimientos con paginación
     * @param int $pagina Número de página
     * @param int $porPagina Elementos por página
     * @return array Lista de mantenimientos
     * @throws Exception Si hay error en la consulta
     */
    public function listar($pagina = 1, $porPagina = 10) {
        // Validar parámetros
        $pagina = max(1, (int)$pagina);
        $porPagina = max(1, min(100, (int)$porPagina));
        
        $conn = $this->conexion->conectando();
        if (!$conn) {
            throw new Exception("Error de conexión a la base de datos");
        }
        
        try {
            $desde = ($pagina - 1) * $porPagina;
            
            $query = "SELECT m.*, c.tipo as tipo_consola 
                      FROM mantenimiento m
                      JOIN consola c ON m.id_consola = c.id
                      ORDER BY 
                        CASE m.estado
                          WHEN 'en_proceso' THEN 1
                          WHEN 'pendiente' THEN 2
                          WHEN 'completado' THEN 3
                          ELSE 4
                        END,
                        m.fecha_programada ASC
                      LIMIT ?, ?";
            
            $stmt = $conn->prepare($query);
            if (!$stmt) {
                throw new Exception("Error en la preparación de la consulta: " . $conn->error);
            }
            
            $stmt->bind_param("ii", $desde, $porPagina);
            if (!$stmt->execute()) {
                throw new Exception("Error al ejecutar la consulta: " . $stmt->error);
            }
            
            $result = $stmt->get_result();
            $mantenimientos = [];
            
            while ($row = $result->fetch_assoc()) {
                $row['clase_estado'] = $this->determinarClaseEstado($row['estado'], $row['fecha_programada']);
                $mantenimientos[] = $row;
            }
            
            return $mantenimientos;
        } finally {
            if (isset($stmt)) $stmt->close();
            $conn->close();
        }
    }

    /**
     * Cuenta el total de mantenimientos
     * @return int Total de registros
     * @throws Exception Si hay error en la consulta
     */
    public function contar() {
        $conn = $this->conexion->conectando();
        if (!$conn) {
            throw new Exception("Error de conexión a la base de datos");
        }
        
        try {
            $result = $conn->query("SELECT COUNT(*) as total FROM mantenimiento");
            if (!$result) {
                throw new Exception("Error en la consulta: " . $conn->error);
            }
            $row = $result->fetch_assoc();
            return (int)$row['total'];
        } finally {
            $conn->close();
        }
    }

    /**
     * Obtiene un mantenimiento por ID
     * @param int $id ID del mantenimiento
     * @return array|null Datos del mantenimiento o null si no existe
     * @throws Exception Si hay error en la consulta
     */
    public function obtenerPorId($id) {
        if (!is_numeric($id) || $id <= 0) {
            throw new InvalidArgumentException("ID de mantenimiento no válido");
        }
        
        $conn = $this->conexion->conectando();
        if (!$conn) {
            throw new Exception("Error de conexión a la base de datos");
        }
        
        try {
            $stmt = $conn->prepare("SELECT m.*, c.tipo as tipo_consola 
                                   FROM mantenimiento m
                                   JOIN consola c ON m.id_consola = c.id
                                   WHERE m.id = ?");
            if (!$stmt) {
                throw new Exception("Error en la preparación de la consulta: " . $conn->error);
            }
            
            $stmt->bind_param("i", $id);
            if (!$stmt->execute()) {
                throw new Exception("Error al ejecutar la consulta: " . $stmt->error);
            }
            
            $result = $stmt->get_result();
            return $result->fetch_assoc();
        } finally {
            if (isset($stmt)) $stmt->close();
            $conn->close();
        }
    }

    /**
     * Agrega un nuevo mantenimiento
     * @param array $data Datos del mantenimiento
     * @return bool True si se agregó correctamente
     * @throws Exception Si hay error en la consulta o datos inválidos
     */
    public function agregar($data) {
        $this->validarDatosMantenimiento($data);
        
        $conn = $this->conexion->conectando();
        if (!$conn) {
            throw new Exception("Error de conexión a la base de datos");
        }
        
        try {
            $stmt = $conn->prepare(
                "INSERT INTO mantenimiento 
                 (tipo, descripcion, id_consola, fecha_programada) 
                 VALUES (?, ?, ?, ?)"
            );
            
            if (!$stmt) {
                throw new Exception("Error en la preparación de la consulta: " . $conn->error);
            }
            
            $stmt->bind_param(
                "ssis", 
                $data['tipo'],
                $data['descripcion'],
                $data['id_consola'],
                $data['fecha_programada']
            );

            return $stmt->execute();
        } finally {
            if (isset($stmt)) $stmt->close();
            $conn->close();
        }
    }

    // ... (resto de métodos como actualizar, iniciar, completar, cancelar con la misma estructura)

    /**
     * Determina la clase CSS según estado y fecha
     * @param string $estado Estado del mantenimiento
     * @param string|null $fechaProgramada Fecha programada
     * @return string Clase CSS
     */
    private function determinarClaseEstado($estado, $fechaProgramada) {
        if ($estado === 'completado') return 'completado';
        if ($estado === 'cancelado') return 'cancelado';
        if ($estado === 'en_proceso') return 'en-proceso';
        
        if (empty($fechaProgramada)) {
            return 'programado';
        }
        
        try {
            $hoy = new DateTime();
            $fechaMant = new DateTime($fechaProgramada);
            
            if ($fechaMant < $hoy) return 'vencido';
            
            $diferencia = $hoy->diff($fechaMant);
            $dias = $diferencia->days;

            if ($dias <= 3) return 'urgente';
            if ($dias <= 7) return 'proximo';
            return 'programado';
        } catch (Exception $e) {
            error_log("Error al procesar fecha: " . $e->getMessage());
            return 'programado';
        }
    }

    /**
     * Valida los datos básicos de un mantenimiento
     * @param array $data Datos a validar
     * @throws InvalidArgumentException Si los datos no son válidos
     */
    private function validarDatosMantenimiento($data) {
        if (empty($data['tipo'])) {
            throw new InvalidArgumentException("El tipo de mantenimiento es requerido");
        }
        if (empty($data['descripcion']) || strlen($data['descripcion']) > 250) {
            throw new InvalidArgumentException("La descripción es requerida y debe tener máximo 250 caracteres");
        }
        if (!is_numeric($data['id_consola']) || $data['id_consola'] <= 0) {
            throw new InvalidArgumentException("ID de consola no válido");
        }
        if (empty($data['fecha_programada'])) {
            throw new InvalidArgumentException("La fecha programada es requerida");
        }
    }
}

?>