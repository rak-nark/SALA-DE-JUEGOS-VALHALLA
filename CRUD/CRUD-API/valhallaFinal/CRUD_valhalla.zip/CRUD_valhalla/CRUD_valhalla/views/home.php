<?php 
include ("../connection/conexion.php");
 include ("../controller/clienteControlador.php"); 
?>
<?php 
$c = new conexion();
$cone =$c -> conectando();
$sql = "select max(idCliente) from cliente";
$rs1 = mysqli_query(mysql:$cone,query:$sql);
$arreglo=mysqli_fetch_row(result:$rs1);
if($arreglo[0]>0){
  $suma = 0;
  $numero = $arreglo[0];
  $suma = 1 + $arreglo[0];
}else{
  $suma = 0;
  $numero = $arreglo[0];
  $suma = 1 + $arreglo[0];
  $obj->idCliente = $suma;
}
$obj->idCliente = $suma;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio de sesión</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../configs/css/home.css">
</head>
<body>  
    <div class="wrapper">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
    <ul>
        <li><a href="home.php" title="Gestión usuarios"><i class="fa-solid fa-circle-user"></i><span
                    class="menu-text">Gestión Clientes</span></a></li>
        <li><a href="consola.php" title="Consolas"><i class="fa-solid fa-pager"></i><span
                    class="menu-text">Consolas</span></a></li>
        <li><a href="mantenimiento.php" title="Registrar Mantenimiento"><i class="fa-solid fa-book"></i><span
                    class="menu-text">Mantenimiento</span></a></li>
        <li><a href="prestamo.php" title="Prestamos"><i class="fa-solid fa-globe"></i><span
                    class="menu-text">Préstamos</span></a></li>
        <li><a href="venta.php" title="Consultar Ventas"><i class="fa-solid fa-money-bill-wave"></i><span
                    class="menu-text">Total Ventas</span></a></li>
       <li><a href="ganancias.php" title="Ganancias"><i class="fa-solid fa-chart-line"></i><span class="menu-text">Ganancias</span></a></li>
    </ul>
</div>

        <div class="main-content">
            <!-- Navbar superior -->
            <div class="navbar">
                <div class="navbar-left">
                    <button id="menuToggle"><i class="fas fa-bars"></i></button>
                    <span>Panel de Navegación</span>
                </div>
                <div class="navbar-right">
                    <div class="profile">Perfil <i class="fas fa-user"></i></div>
                    <div class="submenu">
                        <a href="#" class="submenu-toggle">Menú <i class="fas fa-bars"></i></a>
                        <div class="submenu-content">
                            <a href="login.php">Iniciar Sesión</a>
                            <a href="resgitro.php">Registrar</a>
                            <a href="logout.php">Cerrar Sesión</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Contenido -->
            <div class="content">
                <div class="container-md">
                    <nav class="navbar navbar-expand-lg navbar-light bg-light">
                        <div class="container-fluid">
                            <!-- Logo -->
                            <a class="navbar-brand" href="#">
                                <img src="../configs/image/Imagen2-removebg-preview (1).png" alt="Logo" width="150"
                                    height="100">
                            </a>
                            <!-- Botón para toggler en vista móvil -->
                            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                                aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>
                            <!-- Contenido del navbar -->
                            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                <!-- Menú de navegación -->
                                <form class="d-flex" method="post">
                                    <input class="form-control me-2" type="search" name="nombreCliente" id="idCliente"
                                        placeholder="Search" aria-label="Search">
                                    <button class="btn btn-outline-success" type="submit" name="buscar"
                                        id="buscar">Buscar</button>
                                </form>
                            </div>
                        </div>
                    </nav>
                    <center>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                            data-bs-target="#exampleModal">
                            Ingresar cliente
                        </button>
                    </center>
                    <!-- Modal de Edición -->
                    <div class="modal fade" id="editModal_<?php echo $fila['idCliente']; ?>" tabindex="-1"
                        aria-labelledby="editModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Editar Cliente</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form method="post">
                                        <input type="hidden" name="idCliente" value="<?php echo $fila['idCliente']; ?>">
                                        <div class="mb-3">
                                            <label for="nombreCliente_<?php echo $fila['idCliente']; ?>"
                                                class="form-label">Nombre</label>
                                            <input type="text" name="nombreCliente" class="form-control"
                                                id="nombreCliente_<?php echo $fila['idCliente']; ?>"
                                                value="<?php echo $fila['nombreCliente']; ?>">
                                        </div>
                                        <div class="mb-3">
                                            <label for="apellidoCliente_<?php echo $fila['idCliente']; ?>"
                                                class="form-label">Apellido</label>
                                            <input type="text" name="apellidoCliente" class="form-control"
                                                id="apellidoCliente_<?php echo $fila['idCliente']; ?>"
                                                value="<?php echo $fila['apellidoCliente']; ?>">
                                        </div>
                                        <div class="mb-3">
                                            <label for="correoCliente_<?php echo $fila['idCliente']; ?>"
                                                class="form-label">Correo</label>
                                            <input type="email" name="correoCliente" class="form-control"
                                                id="correoCliente_<?php echo $fila['idCliente']; ?>"
                                                value="<?php echo $fila['correoCliente']; ?>">
                                        </div>
                                        <div class="mb-3">
                                            <label for="contrasenaCliente_<?php echo $fila['idCliente']; ?>"
                                                class="form-label">Contrasena</label>
                                            <input type="password" name="contrasenaCliente" class="form-control"
                                                id="contrasenaCliente_<?php echo $fila['idCliente']; ?>" value="">
                                        </div>
                                        <div class="mb-3">
                                            <label for="rol_<?php echo $fila['idCliente']; ?>"
                                                class="form-label">Rol</label>
                                            <select name="rol" class="form-control"
                                                id="rol_<?php echo $fila['idCliente']; ?>">
                                                <option value="usuario" <?php echo ($fila['rol']=='usuario' ||
                                                    $fila['rol']==null) ? 'selected' : '' ; ?>>Usuario</option>
                                                <option value="admin" <?php echo ($fila['rol']=='admin' ) ? 'selected'
                                                    : '' ; ?>>Admin</option>
                                            </select>
                                        </div>
                                        <button type="submit" name="modificar" value="modificar"
                                            class="btn btn-primary">Actualizar</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Tabla -->
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th scope="col">Código</th>
                                    <th scope="col">Nombre</th>
                                    <th scope="col">Apellido</th>
                                    <th scope="col">Correo</th>
                                    <th scope="col">Contrasena</th>
                                    <th scope="col">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
            if (empty($res)) {
                echo "<tr><td colspan='6'>No hay registros</td></tr>";
            } else {
                foreach ($res as $fila) {
                    ?>
                                <tr>
                                    <td>
                                        <?php echo $fila['idCliente']; ?>
                                    </td>
                                    <td>
                                        <?php echo $fila['nombreCliente']; ?>
                                    </td>
                                    <td>
                                        <?php echo $fila['apellidoCliente']; ?>
                                    </td>
                                    <td>
                                        <?php echo $fila['correoCliente']; ?>
                                    </td>
                                    <td>
                                        <?php echo $fila['contrasenaCliente']; ?>
                                    </td>
                                    <td>
                                        <form action="" method="post" style="display:inline;">
                                            <input type="hidden" name="idCliente"
                                                value="<?php echo $fila['idCliente']; ?>">
                                            <button type="submit" name="elimina" value="elimina"
                                                class="btn btn-danger">Eliminar</button>
                                        </form>
                                        <form action="" method="post" style="display:inline;">
                                            <input type="hidden" name="idCliente"
                                                value="<?php echo $fila['idCliente']; ?>">
                                            <!-- Botón Editar -->
                                            <button type="button" class="btn btn-warning" data-bs-toggle="modal"
                                                data-bs-target="#editModal_<?php echo $fila['idCliente']; ?>">
                                                Editar
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <!-- Modal de edición -->
                                <div class="modal fade" id="editModal_<?php echo $fila['idCliente']; ?>" tabindex="-1"
                                    aria-labelledby="editModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Editar Cliente</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <form method="post">
                                                    <input type="hidden" name="idCliente"
                                                        value="<?php echo $fila['idCliente']; ?>">
                                                    <div class="mb-3">
                                                        <label for="nombreCliente_<?php echo $fila['idCliente']; ?>"
                                                            class="form-label">Nombre</label>
                                                        <input type="text" name="nombreCliente" class="form-control"
                                                            id="nombreCliente_<?php echo $fila['idCliente']; ?>"
                                                            value="<?php echo $fila['nombreCliente']; ?>">
                                                    </div>
                                                    <div class="mb-3">
                                                        <label for="apellidoCliente_<?php echo $fila['idCliente']; ?>"
                                                            class="form-label">Apellido</label>
                                                        <input type="text" name="apellidoCliente" class="form-control"
                                                            id="apellidoCliente_<?php echo $fila['idCliente']; ?>"
                                                            value="<?php echo $fila['apellidoCliente']; ?>">
                                                    </div>
                                                    <div class="mb-3">
                                                        <label for="correoCliente_<?php echo $fila['idCliente']; ?>"
                                                            class="form-label">Correo</label>
                                                        <input type="email" name="correoCliente" class="form-control"
                                                            id="correoCliente_<?php echo $fila['idCliente']; ?>"
                                                            value="<?php echo $fila['correoCliente']; ?>">
                                                    </div>
                                                    <div class="mb-3">
                                                        <label for="contrasenaCliente_<?php echo $fila['idCliente']; ?>"
                                                            class="form-label">Contrasena</label>
                                                        <input type="password" name="contrasenaCliente"
                                                            class="form-control"
                                                            id="contrasenaCliente_<?php echo $fila['idCliente']; ?>"
                                                            value="">
                                                    </div>
                                                    <button type="submit" name="modificar" value="modificar"
                                                        class="btn btn-primary">Actualizar</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                }
            }
            ?>
                            </tbody>
                        </table>
                    </div>
                    <nav aria-label="Page navigation example">
                        <ul class="pagination justify-content-end">
                            <?php 
            if($pagina != 1) {
            ?>
                            <li class="page-item">
                                <a class="page-link" href="?pagina=<?php echo 1; ?>">Primera</a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="?pagina=<?php echo $pagina - 1; ?>">Anterior</a>
                            </li>
                            <?php
            }
            for($i = 1; $i <= $totalPaginas; $i++) {
                if($i == $pagina) {
                    echo '<li class="page-item active" aria-current="page"><a class="page-link" href="?pagina='.$i.'">'.$i.'</a></li>';    
                } else {
                    echo '<li class="page-item"><a class="page-link" href="?pagina='.$i.'">'.$i.'</a></li>'; 
                }
            }
            if($pagina != $totalPaginas) {
            ?>
                            <li class="page-item">
                                <a class="page-link" href="?pagina=<?php echo $pagina + 1; ?>">Siguiente</a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="?pagina=<?php echo $totalPaginas; ?>">Ultima</a>
                            </li>
                            <?php
            }
            ?>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>
        <script src="../configs/js/home.js"></script>
</body>
</html>