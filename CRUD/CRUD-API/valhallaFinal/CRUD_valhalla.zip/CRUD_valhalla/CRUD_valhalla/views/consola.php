<?php 
include ("../connection/conexion.php");
include ("../controller/consolaControlador.php");
?>
<?php 
$c = new conexion();
$cone =$c -> conectando();
$sql = "select max(id) from consola";
$rs1 = mysqli_query(mysql:$cone,query:$sql);
$arreglo=mysqli_fetch_row(result:$rs1);
if($arreglo[0]>0){
  $suma = 0;
  $numero = $arreglo[0];
  $suma = 1 + $arreglo[0];
}else{
  $suma = 0;
  $numero = $arreglo[0];
  $suma = 1 + $arreglo[0];
  $obj->id = $suma;
}
$obj->id = $suma;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consolas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../configs/css/consola.css">
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
    <ul>
        <li><a href="home.php" title="Gestión usuarios"><i class="fa-solid fa-circle-user"></i><span
                    class="menu-text">Gestión Clientes</span></a></li>
        <li><a href="consola.php" title="Consolas"><i class="fa-solid fa-pager"></i><span
                    class="menu-text">Consolas</span></a></li>
        <li><a href="mantenimiento.php" title="Registrar Mantenimiento"><i class="fa-solid fa-book"></i><span
                    class="menu-text">Mantenimiento</span></a></li>
        <li><a href="prestamo.php" title="Prestamos"><i class="fa-solid fa-globe"></i><span
                    class="menu-text">Préstamos</span></a></li>
        <li><a href="venta.php" title="Consultar Ventas"><i class="fa-solid fa-money-bill-wave"></i><span
                    class="menu-text">Total Ventas</span></a></li>
       <li><a href= "ganancias.php" title="Ganancias"><i class="fa-solid fa-chart-line"></i><span class="menu-text">Ganancias</span></a></li>
    </ul>
</div>
        <div class="main-content">
            <!-- Navbar superior -->
            <div class="navbar">
                <div class="navbar-left">
                    <button id="menuToggle"><i class="fas fa-bars"></i></button>
                    <span>Panel de Navegación</span>
                </div>
                <div class="navbar-right">
                    <div class="profile">Perfil <i class="fas fa-user"></i></div>
                    <div class="submenu">
                        <a href="#" class="submenu-toggle">Menú <i class="fas fa-bars"></i></a>
                        <div class="submenu-content">
                            <a href="login.php">Iniciar Sesión</a>
                            <a href="resgitro.php">Registrar</a>
                            <a href="logout.php">Cerrar Sesión</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Contenido -->
            <div class="content">
                <div class="container-md">
                    <nav class="navbar navbar-expand-lg navbar-light bg-light">
                        <div class="container-fluid">
                            <!-- Logo -->
                            <a class="navbar-brand" href="#">
                                <img src="../configs/image/Imagen2-removebg-preview (1).png" alt="Logo" width="150"
                                    height="100">
                            </a>
                            <!-- Botón para toggler en vista móvil -->
                            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                                aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>
                            <!-- Contenido del navbar -->
                            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                <!-- Menú de navegación -->
                                <form class="d-flex" method="post">
                                    <input class="form-control me-2" type="search" name="nombreCliente" id="idCliente"
                                        placeholder="Search" aria-label="Search">
                                    <button class="btn btn-outline-success" type="submit" name="buscar"
                                        id="buscar">Buscar</button>
                                </form>
                            </div>
                        </div>
                    </nav>
                    <center>
                        <nav>
                            <!-- <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                Ingresar consola
                </nav> -->
                        </nav>
                    </center>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover mt-3">
                            <thead>
                                <tr>
                                    <th scope="col">Código</th>
                                    <th scope="col">Tipo</th>
                                    <th scope="col">Disponibilidad</th>
                                    <th scope="col">Acciones</th>
                                    <th scope="col"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
            if ($res == 0) {
                echo "<tr><td colspan='5' class='text-center'>No hay registros</td></tr>";
            } else {
                do {
            ?>
                                <tr>
                                    <td>
                                        <?php echo $res[0]; ?>
                                    </td>
                                    <td>
                                        <?php echo $res[1]; ?>
                                    </td>
                                    <td>
                                        <?php echo ($res[2] == 1) ? 'Disponible' : 'No disponible'; ?>
                                    </td>
                                    <td>
                                        <form action="" method="post">
                                            <input type="hidden" name="id" value="<?php echo $res[0]; ?>">
                                            <!--<button type="submit" src="home.php" name="elimina" value="elimina" class="btn btn-danger">Eliminar</button>-->
                                        </form>
                                    </td>
                                    <td>
                                        <button type="button" class="btn btn-warning" data-bs-toggle="modal"
                                            data-bs-target="#editModal_<?php echo $res[0]; ?>">Editar</button>
                                    </td>
                                </tr>
                                <!-- Modal de edición -->
                                <div class="modal fade" id="editModal_<?php echo $res[0]; ?>" tabindex="-1"
                                    aria-labelledby="editModalLabel_<?php echo $res[0]; ?>" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="editModalLabel_<?php echo $res[0]; ?>">
                                                    Editar Consola</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <form method="post">
                                                    <input type="hidden" name="id" value="<?php echo $res[0]; ?>">
                                                    <div class="mb-3">
                                                        <label for="tipo_<?php echo $res[0]; ?>"
                                                            class="form-label">Tipo</label>
                                                        <input type="text" name="tipo" class="form-control"
                                                            id="tipo_<?php echo $res[0]; ?>"
                                                            value="<?php echo $res[1]; ?>">
                                                    </div>
                                                    <div class="mb-3">
                                                        <label for="disponibilidad_<?php echo $res[0]; ?>"
                                                            class="form-label">Disponibilidad</label>
                                                        <select name="disponibilidad" class="form-control"
                                                            id="disponibilidad_<?php echo $res[0]; ?>">
                                                            <option value="1" <?php echo ($res[2]==1) ? 'selected' : ''
                                                                ; ?>>Disponible</option>
                                                            <option value="0" <?php echo ($res[2]==0) ? 'selected' : ''
                                                                ; ?>>No disponible</option>
                                                        </select>
                                                    </div>
                                                    <button type="submit" name="modificar" value="modificar"
                                                        class="btn btn-primary">Actualizar</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                } while ($res = mysqli_fetch_array($ejecuta));
            }
            ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- Modal de ingreso -->
                    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Ingrese los consolas registrados</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form method="post">
                                        <div class="mb-3">
                                            <input type="hidden" name="id" value="<?php echo $obj->id; ?>"
                                                class="form-control" id="exampleInputText1">
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleInputText1" class="form-label">Tipo</label>
                                            <input type="text" name="tipo" class="form-control" id="exampleInputText1">
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleInputText1" class="form-label">Disponibilidad</label>
                                            <select name="disponibilidad" class="form-control" id="exampleInputText1">
                                                <option value="1">Disponible</option>
                                                <option value="0">No disponible</option>
                                            </select>
                                        </div>
                                        <button type="submit" class="btn btn-primary" name="guarda"
                                            value="guarda">Ingresar</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <nav aria-label="Page navigation example">
                        <ul class="pagination justify-content-end">
                            <?php 
                if ($pagina != 1) {
                ?>
                            <li class="page-item">
                                <a class="page-link" href="?pagina=<?php echo 1; ?>">&laquo;</a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="?pagina=<?php echo $pagina - 1; ?>">&lsaquo;</a>
                            </li>
                            <?php
                }
                for ($i = 1; $i <= $totalPaginas; $i++) {
                    if ($i == $pagina) {
                        echo '<li class="page-item active" aria-current="page"><a class="page-link" href="?pagina=' . $i . '">' . $i . '</a></li>';
                    } else {
                        echo '<li class="page-item"><a class="page-link" href="?pagina=' . $i . '">' . $i . '</a></li>';
                    }
                }
                if ($pagina != $totalPaginas) {
                ?>
                            <li class="page-item">
                                <a class="page-link" href="?pagina=<?php echo $pagina + 1; ?>">&rsaquo;</a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="?pagina=<?php echo $totalPaginas; ?>">&raquo;</a>
                            </li>
                            <?php
                }
                ?>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
            crossorigin="anonymous"></script>
            <script src="../configs/js/consola.js"></script>
</body>
</html>